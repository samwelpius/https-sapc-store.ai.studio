import serverless from "serverless-http";
import { app } from "../../server";

// Export the serverless-wrapped express instance as the Netlify function handler
export const handler = serverless(app);
