import React, { useState, useEffect } from 'react';
import { db, collection, query, where, getDocs, onSnapshot } from '../supabase';
import { UserProfile, INVESTMENT_LEVELS } from '../types';
import { 
  Users, Share2, Clipboard, Award, ShieldCheck, ArrowRight, TrendingUp, CheckCircle2
} from 'lucide-react';

interface ReferralCenterProps {
  profile: UserProfile;
}

export default function ReferralCenter({ profile }: ReferralCenterProps) {
  const [referredUsersList, setReferredUsersList] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const referralLink = `${window.location.origin}/?ref=${profile.referralCode}`;

  useEffect(() => {
    if (!profile.referralCode) return;

    // Fetch users referred by this user
    const refQuery = query(
      collection(db, 'users'),
      where('referredBy', '==', profile.referralCode)
    );

    const unsub = onSnapshot(refQuery, (snapshot) => {
      setReferredUsersList(snapshot.docs.map(doc => doc.data() as UserProfile));
      setLoading(false);
    }, (err) => {
      console.error(err);
      setLoading(false);
    });

    return () => unsub();
  }, [profile.referralCode]);

  const copyToClipboard = (text: string, title: string) => {
    navigator.clipboard.writeText(text);
    alert(`${title} imesafishwa na kunakiliwa kwenye clipboard!`);
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Header Sharing Center card */}
      <div className="bg-white/[0.03] border border-white/10 p-5 rounded-2xl space-y-4 glass">
        <div className="text-center space-y-1">
          <Users className="w-8 h-8 text-orange-400 mx-auto" />
          <h2 className="text-base font-extrabold text-white uppercase tracking-wider">Mwaliko na Zawadi (Referral Program)</h2>
          <p className="text-xs text-white/60 font-mono">Alika marafiki wajiunge na SAPC Store na ujipatie hadi TZS 10,000 kwa kila upgrade!</p>
        </div>

        {/* Real-time referral code & links layout */}
        <div className="space-y-3">
          <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex justify-between items-center text-xs font-mono">
            <div>
              <span className="block text-[8px] text-white/40 uppercase">Referral Code Yako</span>
              <span className="text-sm font-black text-white">{profile.referralCode}</span>
            </div>
            <button
              onClick={() => copyToClipboard(profile.referralCode, "Kodi ya mwaliko")}
              className="px-3 py-1.5 bg-[#0A0A0C] hover:bg-white/5 text-orange-400 font-bold rounded-lg border border-white/10 transition-colors"
            >
              Copy Code
            </button>
          </div>

          <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex justify-between items-center text-xs font-mono">
            <div>
              <span className="block text-[8px] text-white/40 uppercase">Kiungo cha Mwaliko (Referral Link)</span>
              <span className="text-[10px] text-white/60 truncate max-w-[190px] block">{referralLink}</span>
            </div>
            <button
              onClick={() => copyToClipboard(referralLink, "Kiungo cha mwaliko")}
              className="px-3 py-1.5 bg-orange-500 hover:bg-orange-400 text-black font-bold rounded-lg transition-colors cursor-pointer"
            >
              Share Link
            </button>
          </div>
        </div>
      </div>

      {/* 2. Referral structure guide cards */}
      <div className="bg-white/[0.03] border border-white/10 p-5 rounded-2xl space-y-3 glass">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono border-b border-white/5 pb-2">
          Mfumo wa Bonasi (Referral Bonus Structure)
        </h3>

        <div className="space-y-2 text-xs font-mono">
          <div className="flex justify-between items-center py-1.5 border-b border-white/5">
            <span className="text-white/60">Mwalikwa akijiunga Kiwango 1:</span>
            <span className="text-orange-400 font-bold">+ TZS 2,000</span>
          </div>
          <div className="flex justify-between items-center py-1.5 border-b border-white/5">
            <span className="text-white/60">Mwalikwa akijiunga Kiwango 2:</span>
            <span className="text-orange-400 font-bold">+ TZS 5,000</span>
          </div>
          <div className="flex justify-between items-center py-1.5 border-b border-white/5">
            <span className="text-white/60">Mwalikwa akijiunga Kiwango 3:</span>
            <span className="text-orange-400 font-bold">+ TZS 10,000</span>
          </div>
          <div className="flex justify-between items-center py-1.5 last:border-0">
            <span className="text-white/60">Mwalikwa akijiunga Kiwango 4:</span>
            <span className="text-orange-400 font-bold">+ TZS 10,000</span>
          </div>
        </div>
      </div>

      {/* 3. List of Referred users in real-time */}
      <div className="bg-white/[0.03] border border-white/10 p-5 rounded-2xl space-y-3 glass">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono">
          Watu Uliowaalika ({referredUsersList.length})
        </h3>

        <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
          {loading ? (
            <p className="text-xs text-white/40 text-center py-4">Inapakia marafiki...</p>
          ) : referredUsersList.length === 0 ? (
            <p className="text-xs text-white/40 text-center py-4">Hujaalika mtu yeyote bado. Anza kushare kiungo upate faida!</p>
          ) : (
            referredUsersList.map((user) => (
              <div key={user.uid} className="p-3 bg-black/40 border border-white/10 rounded-xl flex justify-between items-center font-mono text-xs">
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="font-bold text-white mb-0.5">{user.username}</p>
                    {(user.role === 'admin' || user.email?.trim().toLowerCase() === 'djafloekemoda@gmail.com') && (
                      <CheckCircle2 className="w-3.5 h-3.5 fill-blue-500 text-[#0c0c0e] shrink-0" title="Admin Verified" />
                    )}
                  </div>
                  <p className="text-[10px] text-white/40 font-mono">Kujiunga: {new Date(user.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <span className="inline-block px-2 py-0.5 bg-orange-500/10 text-orange-400 border border-orange-500/20 text-[9px] rounded-full uppercase">
                    Kiwango {user.level}
                  </span>
                  <p className="text-[9px] text-white/40 mt-1">Status: Active</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}
