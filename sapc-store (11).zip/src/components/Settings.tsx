import React, { useState } from 'react';
import { 
  db, auth, setDoc, doc, signOut
} from '../supabase';
import { UserProfile } from '../types';
import { 
  Settings as SettingsIcon, User, Lock, Wallet, LogOut, CheckCircle2, 
  Save, AlertCircle, Sparkles, Smartphone, KeyRound, Shield, Check,
  Database
} from 'lucide-react';
import Support from './Support';
import DepositWithdraw from './DepositWithdraw';

interface SettingsProps {
  profile: UserProfile;
  onRefreshProfile: () => Promise<void>;
  onNavigate: (tab: string) => void;
}

export default function Settings({ profile, onRefreshProfile, onNavigate }: SettingsProps) {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'security' | 'support'>('profile');
  
  // Profile update states
  const [username, setUsername] = useState(profile.username || '');
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState<string | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);

  // Firebase connection states
  const [dbSuccess, setDbSuccess] = useState<string | null>(null);
  const [dbError, setDbError] = useState<string | null>(null);

  // Security password update states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [securityLoading, setSecurityLoading] = useState(false);
  const [securitySuccess, setSecuritySuccess] = useState<string | null>(null);
  const [securityError, setSecurityError] = useState<string | null>(null);

  // Payment defaults states
  const [defaultNetwork, setDefaultNetwork] = useState((profile as any).defaultNetwork || 'M-Pesa');
  const [defaultPhone, setDefaultPhone] = useState((profile as any).defaultPhone || '');
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState<string | null>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  const isAdmin = profile.role === 'admin' || profile.email?.trim().toLowerCase() === 'djafloekemoda@gmail.com';

  // Handler for Profile Update
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError(null);
    setProfileSuccess(null);

    if (!username.trim()) {
      setProfileError("Tafadhali jaza jina la mtumiaji (Username).");
      return;
    }

    setProfileLoading(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await setDoc(userRef, {
        username: username.trim()
      }, { merge: true });

      setProfileSuccess("Wasifu wako umesasishwa kikamilifu! ✨");
      await onRefreshProfile();
    } catch (err: any) {
      setProfileError(err.message || "Imeshindwa kusasisha wasifu.");
    } finally {
      setProfileLoading(false);
    }
  };

  // Handler for Password Change (Synchronized with localStorage authUsers)
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);
    setSecuritySuccess(null);

    if (!currentPassword || !newPassword || !confirmPassword) {
      setSecurityError("Tafadhali jaza maeneo yote ya nenosiri.");
      return;
    }

    if (newPassword.length < 5) {
      setSecurityError("Nenosiri jipya lazima liwe na herufi zisizopungua 5.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setSecurityError("Nenosiri jipya na lile la uthibitisho hayalingani.");
      return;
    }

    setSecurityLoading(true);
    try {
      const stored = localStorage.getItem('sapc_auth_users');
      if (!stored) throw new Error("Mfumo wa auth haujapatikana.");

      const usersList = JSON.parse(stored);
      const userIndex = usersList.findIndex((u: any) => u.uid === profile.uid);

      if (userIndex === -1) {
        throw new Error("Akaunti yako haikutambuliwa kwenye hifadhidata ya usajili.");
      }

      const userRecord = usersList[userIndex];
      if (userRecord.password !== currentPassword) {
        throw new Error("Nenosiri la sasa (Current Password) si sahihi.");
      }

      // Update password
      userRecord.password = newPassword;
      usersList[userIndex] = userRecord;
      localStorage.setItem('sapc_auth_users', JSON.stringify(usersList));

      setSecuritySuccess("Nenosiri jipya limesetwa kikamilifu! 🔒");
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setSecurityError(err.message || "Imeshindwa kuboresha nenosiri.");
    } finally {
      setSecurityLoading(false);
    }
  };

  // Handler for Saving Default Payment Details
  const handleUpdatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError(null);
    setPaymentSuccess(null);

    if (!defaultPhone.trim()) {
      setPaymentError("Tafadhali weka namba ya simu ya malipo.");
      return;
    }

    setPaymentLoading(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await setDoc(userRef, {
        defaultNetwork,
        defaultPhone: defaultPhone.trim()
      }, { merge: true });

      setPaymentSuccess("Njia chaguomsingi ya malipo imehifadhiwa! ⚡");
      await onRefreshProfile();
    } catch (err: any) {
      setPaymentError(err.message || "Imeshindwa kusave njia ya malipo.");
    } finally {
      setPaymentLoading(false);
    }
  };

  // Native Firebase is pre-configured and loaded automatically

  const handleSignOutTrigger = async () => {
    if (window.confirm("Je unataka kuondoka (Log Out) kwenye akaunti yako ya SAPC?")) {
      await signOut(auth);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Dynamic Settings Banner */}
      <div className="relative overflow-hidden bg-gradient-to-tr from-orange-500/10 via-black/40 to-transparent p-5 rounded-3xl border border-white/10 glass">
        <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/10 rounded-full filter blur-3xl pointer-events-none text-white font-mono"></div>
        <div className="flex justify-between items-center relative z-10">
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <SettingsIcon className="w-5 h-5 text-orange-400 rotate-45 animate-spin-slow" /> WASIFU NA MALIPO
            </h2>
            <p className="text-[10px] text-white/50 leading-relaxed font-mono mt-1">
              Sanidi wasifu wako, malipo ya haraka, na usalama wa akaunti yako ya SAPC.
            </p>
          </div>
          {isAdmin && (
            <span className="flex items-center gap-1 text-[9px] font-black text-blue-400 bg-blue-500/10 border border-blue-500/30 px-2 py-0.5 rounded-full uppercase font-mono">
              Admin <CheckCircle2 className="w-3.5 h-3.5 fill-blue-500 text-black shrink-0" />
            </span>
          )}
        </div>
      </div>

      {/* Internal Navigation Sub-tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-black/40 p-1.5 rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveSubTab('profile')}
          className={`py-2 text-[9px] font-bold uppercase tracking-wider rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 font-mono cursor-pointer ${
            activeSubTab === 'profile' ? 'bg-orange-500 text-black' : 'text-white/60 hover:text-white hover:bg-white/5'
          }`}
        >
          <User className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Wasifu</span><span className="sm:hidden">Sifa</span>
        </button>

        <button
          onClick={() => setActiveSubTab('security')}
          className={`py-2 text-[9px] font-bold uppercase tracking-wider rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 font-mono cursor-pointer ${
            activeSubTab === 'security' ? 'bg-orange-500 text-black' : 'text-white/60 hover:text-white hover:bg-white/5'
          }`}
        >
          <Lock className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Usalama</span><span className="sm:hidden">Lock</span>
        </button>



        <button
          onClick={() => setActiveSubTab('support')}
          className={`py-2 text-[9px] font-bold uppercase tracking-wider rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 font-mono cursor-pointer text-orange-400 ${
            activeSubTab === 'support' ? 'bg-orange-500 text-black font-semibold' : 'text-orange-400 hover:text-orange-300 hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Msaada</span><span className="sm:hidden font-sans">Chat</span>
        </button>
      </div>

      {/* SUB-TAB CONTENTS */}
      <div className="space-y-6">

        {/* 1. Wasifu (Profile Update) Tab */}
        {activeSubTab === 'profile' && (
          <div className="bg-white/[0.03] border border-white/10 p-5 rounded-3xl space-y-4 glass">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono flex items-center gap-1.5">
              <User className="w-4.5 h-4.5 text-orange-400" /> Tahariri Jina (Edit Display Name)
            </h3>

            <form onSubmit={handleUpdateProfile} className="space-y-3">
              {profileError && (
                <div className="p-3 text-[11px] rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 font-mono flex gap-1.5 items-start">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{profileError}</span>
                </div>
              )}

              {profileSuccess && (
                <div className="p-3 text-[11px] rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 font-mono flex gap-1.5 items-start">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{profileSuccess}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">Barua pepe (Haiwezi kubadilishwa)</label>
                <div className="w-full px-3 py-2 bg-white/[0.02] border border-white/5 text-white/40 rounded-xl text-xs font-mono select-none">
                  {profile.email}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">Jina la Mtumiaji (Username)</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="K.m: Jafeth John"
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={profileLoading}
                className="w-full py-2.5 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 text-black font-extrabold rounded-xl text-xs tracking-wider uppercase cursor-pointer transition-all flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" /> {profileLoading ? "INAHIFADHI..." : "HIFADHI JINA JIPYA"}
              </button>
            </form>

            <div className="bg-black/40 p-4 rounded-2xl border border-white/5 space-y-2 text-xs font-mono">
              <div className="flex justify-between items-center text-[10px] pb-1.5 border-b border-white/5 text-white/40 uppercase font-bold">
                <span>Maelezo ya Akaunti</span>
                <span>SAPC Verification</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Mtumiaji ID:</span>
                <span className="text-white font-mono select-all text-[10px]">{profile.uid}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Kiwango:</span>
                <span className="text-orange-400 font-bold uppercase">Kiwango {profile.level}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50">Status:</span>
                <span className="inline-flex items-center gap-1 text-[9px] bg-green-500/10 text-green-400 px-1.5 py-0.5 rounded border border-green-500/20 font-bold uppercase">
                  Active
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Tarehe ya Usajili:</span>
                <span className="text-white/85">{profile.createdAt ? new Date(profile.createdAt).toLocaleDateString('sw-TZ') : 'Leo'}</span>
              </div>
            </div>
          </div>
        )}


        {/* 3. Usalama (Password Change) Tab */}
        {activeSubTab === 'security' && (
          <div className="bg-white/[0.03] border border-white/10 p-5 rounded-3xl space-y-4 glass">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono flex items-center gap-1.5">
              <KeyRound className="w-4.5 h-4.5 text-orange-400" /> Badili Nenosiri (Change Password)
            </h3>

            <form onSubmit={handleUpdatePassword} className="space-y-3">
              {securityError && (
                <div className="p-3 text-[11px] rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 font-mono flex gap-1.5 items-start">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{securityError}</span>
                </div>
              )}

              {securitySuccess && (
                <div className="p-3 text-[11px] rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 font-mono flex gap-1.5 items-start">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{securitySuccess}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">Nenosiri la sasa (Current Password)</label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">Nenosiri Jipya (New Password)</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Herufi 5+"
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">Thibitisha Nenosiri Jipya</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Kupatanisha nenosiri jipya"
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={securityLoading}
                className="w-full py-2.5 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 text-black font-extrabold rounded-xl text-xs tracking-wider uppercase cursor-pointer transition-all flex items-center justify-center gap-1.5"
              >
                <Lock className="w-4 h-4" /> {securityLoading ? "INABADILISHA..." : "SET NENOSIRI JIPYA SASA"}
              </button>
            </form>
          </div>
        )}



        {activeSubTab === 'support' && (
          <div className="bg-white/[0.01] border border-white/5 rounded-3xl p-1 animate-fade-in">
            <Support profile={profile} />
          </div>
        )}

      </div>

      {/* REMAINDER LOGOUT PANEL - "pia sehem ya log aut haipo weka" */}
      <div className="bg-red-500/5 border border-red-500/20 p-5 rounded-3xl space-y-3.5 glass">
        <h4 className="text-xs font-extrabold text-red-400 uppercase tracking-wider font-mono">ENEO LA KUTOKA KWENYE PROGRAMU (LOGOUT)</h4>
        <p className="text-[10px] text-white/40 font-mono leading-relaxed">
          Kama unataka kuondoka kabisa kwenye akaunti ya sasa ili kuingia na akaunti nyingine kwenye kifaa hiki, bonyeza kitufe kilicho chini.
        </p>
        <button
          onClick={handleSignOutTrigger}
          type="button"
          className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-500 text-white font-extrabold rounded-xl text-[11px] tracking-widest uppercase transition-all shadow-md active:scale-95 cursor-pointer flex items-center justify-center gap-2"
        >
          <LogOut className="w-4 h-4" /> ONDOKA KWENYE AKAUNTI (LOG OUT NOW)
        </button>
      </div>

    </div>
  );
}
