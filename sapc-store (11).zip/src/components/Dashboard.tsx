import React, { useState, useEffect } from 'react';
import { db, doc, onSnapshot, updateDoc, increment, setDoc, collection } from '../supabase';
import { UserProfile } from '../types';
import { 
  Trophy, ShieldCheck, Clock, CheckCircle2, AlertCircle, Wallet, ArrowUpRight, ArrowRight,
  Copy, Smartphone, Receipt, Info, Lock, CreditCard, Coins, Check, Zap
} from 'lucide-react';

interface DashboardProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
}

export interface Betslip {
  id: string;
  bookmaker: 'SportyBet' | 'BetPawa';
  provider: string; // "CHAMPEE TIPS"
  odds: number;
  stake: number;
  expiresInSecs: number; 
  accuracy: string;
  bookingCode: string;
  cost: number;
  games: {
    match: string;
    prediction: string;
    odds: number;
  }[];
  status?: 'active' | 'won' | 'lost';
}

export default function Dashboard({ profile, onNavigate }: DashboardProps) {
  const [unlockedIds, setUnlockedIds] = useState<string[]>([]);
  const [loadingSlipId, setLoadingSlipId] = useState<string | null>(null);
  const [modalSlip, setModalSlip] = useState<Betslip | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Hardcoded premium seed slis matching the picture details exactly
  const initialSlips: Betslip[] = [
    {
      id: "slip_1",
      bookmaker: "SportyBet",
      provider: "CHAMPEE TIPS",
      odds: 10.61,
      stake: 6000,
      expiresInSecs: 20537, // ~5h 42m
      accuracy: "High Accuracy",
      cost: 1500,
      bookingCode: "SB-TZ-834920",
      games: [
        { match: "Real Madrid vs AC Milan", prediction: "Home Win", odds: 1.51 },
        { match: "Liverpool vs Leverkusen", prediction: "Over 2.5 Goals", odds: 1.60 },
        { match: "Lille vs Juventus", prediction: "Both Teams Score (Yes)", odds: 1.85 },
        { match: "Sporting vs Man City", prediction: "Man City Win/Draw", odds: 1.25 },
        { match: "Celtic vs Leipzig", prediction: "Over 1.5 Goals", odds: 1.22 }
      ]
    },
    {
      id: "slip_2",
      bookmaker: "BetPawa",
      provider: "CHAMPEE TIPS",
      odds: 11.88,
      stake: 6000,
      expiresInSecs: 20537, // ~5h 42m
      accuracy: "High Accuracy",
      cost: 1500,
      bookingCode: "BP-542129",
      games: [
        { match: "Man United vs PAOK", prediction: "Home Win & Over 1.5", odds: 1.45 },
        { match: "Lazio vs FC Porto", prediction: "Draw or Porto Win", odds: 1.55 },
        { match: "Galatasaray vs Tottenham", prediction: "Over 2.5 Goals", odds: 1.50 },
        { match: "Chelsea vs FC Noah", prediction: "Chelsea -1.5 Handicap", odds: 1.30 },
        { match: "Olympiacos vs Rangers", prediction: "Both Teams Score (Yes)", odds: 1.80 }
      ]
    },
    {
      id: "slip_3",
      bookmaker: "BetPawa",
      provider: "CHAMPEE TIPS",
      odds: 105.00,
      stake: 7000,
      expiresInSecs: 107597, // ~29h 53m
      accuracy: "High Accuracy",
      cost: 3000,
      bookingCode: "BP-SURE-105",
      games: [
        { match: "Bologna vs Monaco", prediction: "Monaco Win", odds: 2.65 },
        { match: "Shakhtar vs Young Boys", prediction: "Draw", odds: 3.40 },
        { match: "Club Brugge vs Aston Villa", prediction: "Aston Villa Win", odds: 2.15 },
        { match: "Bayern vs Benfica", prediction: "Home Win & BTTS", odds: 2.50 },
        { match: "Inter Milan vs Arsenal", prediction: "Under 2.5 Goals", odds: 1.80 }
      ]
    }
  ];

  const [slipsStates, setSlipsStates] = useState<Betslip[]>(initialSlips);

  // Dynamic editable titles/paragraphs with default fallbacks
  const [customTexts, setCustomTexts] = useState({
    welcomeTitle: "Karibu SAPC TIPS",
    welcomeSubtitle: "Njia salama na rahisi ya kuvuna kupitia mikeka ya uhakika ya soka kila siku.",
    premiumHeader: "MIKEKA YA PREMIUM YA SAPC TIPS",
    premiumPromo: "Mchongo wa Leo: Mikeka ya PREMIUM imewekwa tayari kukulaza na ushindi mnono! 🔥",
    providerName: "SAPC TIPS",
    themeStyle: "cosmic_orange",
    slipsSorting: "countdown",
    slipsLayout: "one_column"
  });

  // Combined single input state (Phone OR Email) for automated PesaPal payments
  const [paymentIdentifier, setPaymentIdentifier] = useState(profile.phoneNumber || profile.email || '');

  // Automated slip-payment states
  const [onlineEmail, setOnlineEmail] = useState(profile.email || '');
  const [onlinePhone, setOnlinePhone] = useState(profile.phoneNumber || '');
  const [pesapalLoading, setPesapalLoading] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState<string | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<'select' | 'pesapal_iframe'>('select');
  
  // Balance fallback click handler
  const [payByBalanceLoading, setPayByBalanceLoading] = useState(false);

  // Recipient phone details config 
  const [operatorRecipients, setOperatorRecipients] = useState<Record<string, { phone: string; name: string }>>({
    'M-Pesa': { phone: '0768 112 233', name: 'SAPC STORE LTD (Vodacom)' },
    'Airtel Money': { phone: '0682 445 566', name: 'SAPC STORE LTD (Airtel)' },
    'Tigo Pesa': { phone: '0715 889 900', name: 'SAPC STORE LTD (Tigo)' },
    'HaloPesa': { phone: '0621 334 455', name: 'SAPC STORE LTD (Halotel)' },
  });

  // 1. Sync BetSlips dynamics from DB & sync Settings text Overrides
  useEffect(() => {
    const unsubSlips = onSnapshot(collection(db, 'betslips'), (snap) => {
      if (!snap.empty) {
        const dbSlips = snap.docs.map(d => d.data() as Betslip);
        setSlipsStates(dbSlips);
      } else {
        // Fallback to static seeds but make sure provider is refined to SAPC TIPS default
        const seedRefined = initialSlips.map(s => ({
          ...s,
          provider: "SAPC TIPS"
        }));
        setSlipsStates(seedRefined);
      }
    }, () => {
      // Offline fallback
      const seedRefined = initialSlips.map(s => ({
        ...s,
        provider: "SAPC TIPS"
      }));
      setSlipsStates(seedRefined);
    });

    const unsubConfig = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setOperatorRecipients({
          'M-Pesa': { phone: data.mPesaNumber || '0768 112 233', name: 'SAPC STORE LTD (Vodacom)' },
          'Airtel Money': { phone: data.airtelNumber || '0682 445 566', name: 'SAPC STORE LTD (Airtel)' },
          'Tigo Pesa': { phone: data.tigoNumber || '0715 889 900', name: 'SAPC STORE LTD (Tigo)' },
          'HaloPesa': { phone: data.haloNumber || '0621 334 455', name: 'SAPC STORE LTD (Halotel)' },
        });

        // Sync administrator dynamic text overrides ("Kisha admin aedit kila kitu mandishi yote")
        setCustomTexts({
          welcomeTitle: data.welcomeTitle || "Karibu SAPC TIPS",
          welcomeSubtitle: data.welcomeSubtitle || "Njia salama na rahisi ya kuvuna kupitia mikeka ya uhakika ya soka kila siku.",
          premiumHeader: data.premiumHeader || "MIKEKA YA PREMIUM YA SAPC TIPS",
          premiumPromo: data.premiumPromo || "Mchongo wa Leo: Mikeka ya PREMIUM imewekwa tayari kukulaza na ushindi mnono! 🔥",
          providerName: data.providerName || "SAPC TIPS",
          themeStyle: data.themeStyle || "cosmic_orange",
          slipsSorting: data.slipsSorting || "countdown",
          slipsLayout: data.slipsLayout || "one_column"
        });
      }
    });

    return () => {
      unsubSlips();
      unsubConfig();
    };
  }, []);

  const unlockSlipInstantly = async (slipId: string, payMethod: string, amount: number, txId?: string) => {
    try {
      // Save unlocked list locally & update db
      const updatedList = [...unlockedIds, slipId];
      setUnlockedIds(updatedList);
      localStorage.setItem(`unlocked_slips_${profile.uid}`, JSON.stringify(updatedList));

      // Standard log & notifications
      const logId = 'log-direct-pay-' + Math.random().toString(36).substring(2, 9);
      await setDoc(doc(db, 'notifications', logId), {
        id: logId,
        userId: profile.uid,
        title: `Malipo ya Mkeka Yamethibitishwa!`,
        message: `Hongera! Malipo yako ya TZS ${amount.toLocaleString()} kupitia ${payMethod} yamethibitishwa. Mkeka umefunguliwa papo hapo kujiandaa kuvuna!`,
        type: 'general',
        read: false,
        createdAt: new Date().toISOString()
      });

      // Write direct deposit entry in firestore as verified for financial record keeping
      const depId = 'dep-auto-' + Math.random().toString(36).substring(2, 9);
      await setDoc(doc(db, 'deposits', depId), {
        id: depId,
        userId: profile.uid,
        username: profile.username,
        amount: amount,
        phone: paymentIdentifier || "AUTOPAY",
        paymentMethod: payMethod,
        transactionId: txId || depId.toUpperCase(),
        status: 'approved',
        createdAt: new Date().toISOString()
      });

      setSuccessMsg("Kamilifu! Malipo yamethibitishwa na mkeka umefunguliwa kiotomatiki! ✨");
    } catch (err: any) {
      setErrorMsg("Kosa limetokea wakati wa ku-unlock: " + err.message);
    }
  };

  const handlePesapalDirectPay = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    
    if (!modalSlip) return;
    const amount = modalSlip.cost;

    const trimmedIdentifier = paymentIdentifier.trim();
    if (!trimmedIdentifier) {
      setErrorMsg("Tafadhali weka Namba ya Simu au Barua Pepe (Email).");
      return;
    }

    let resolvedEmail = "";
    let resolvedPhone = "";

    if (trimmedIdentifier.includes('@')) {
      resolvedEmail = trimmedIdentifier;
      resolvedPhone = profile.phoneNumber || "0755000000";
    } else {
      // It is a phone number, convert/use it
      resolvedPhone = trimmedIdentifier;
      // Synthesize a compliant email for PesaPal structure
      resolvedEmail = `${profile.username || "mteja"}@sapctips.com`;
    }

    setPesapalLoading(true);
    try {
      const response = await fetch("/api/payment/pesapal/initiate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          amount,
          email: resolvedEmail,
          phone: resolvedPhone,
          uid: profile.uid,
          username: profile.username,
          slipId: modalSlip.id
        })
      });

      let data: any = {};
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        data = await response.json();
      } else {
        const textResponse = await response.text();
        console.error("SAPC Dashboard PesaPal Payment failure. Non-JSON Response:", textResponse, "Status Code:", response.status);
        throw new Error(`Kosa la mfumo (Hali ${response.status}): Lango la malipo limefeli kurudisha data sahihi. Wasiliana na msimamizi au thibitisha usanidi wako wa Netlify.`);
      }

      if (!response.ok || data.error) {
        throw new Error(data.error || "PesaPal redirect error");
      }

      if (data.redirect_url) {
        setRedirectUrl(data.redirect_url);
        setCheckoutStep('pesapal_iframe');
      } else {
        throw new Error("Lango la PesaPal limeshindwa kuanza vyema.");
      }
    } catch (err: any) {
      console.error("SAPC Dashboard: PesaPal initiation failed with error:", err);
      setErrorMsg(err.message || "Lango la PesaPal limeshindwa kuanza. Tafadhali rudia tena baada ya muda.");
    } finally {
      setPesapalLoading(false);
    }
  };

  // Register active transparent callback for iframe post-checkout success (Automatically is called by PesaPal redirect callback)
  useEffect(() => {
    (window as any).handleExternalUnlock = (data: { slipId: string; amount: number; ref: string }) => {
      console.log("⚡ SAPC: External automated unlock received on parent page:", data);
      if (data.slipId) {
        unlockSlipInstantly(data.slipId, "PesaPal Automatic", data.amount, data.ref);
        setCheckoutStep('select');
        setRedirectUrl(null);
      }
    };
    return () => {
      delete (window as any).handleExternalUnlock;
    };
  }, [modalSlip, unlockedIds]);

  const handleVerifyPesapalInstant = async () => {
    if (!modalSlip) return;
    setPesapalLoading(true);
    setTimeout(async () => {
      await unlockSlipInstantly(modalSlip.id, "PesaPal Check", modalSlip.cost);
      setCheckoutStep('select');
      setRedirectUrl(null);
      setPesapalLoading(false);
    }, 1500);
  };

  // Dynamically compute layout accents & color themes
  const theme = React.useMemo(() => {
    const style = customTexts.themeStyle || "cosmic_orange";
    switch (style) {
      case "charcoal_red":
        return {
          bgGrad: "from-red-500/10 via-black/40 to-transparent",
          border: "border-red-500/20",
          textAccent: "text-red-400",
          bgAccent: "bg-red-500/10",
          textBranding: "text-red-500",
          borderHover: "hover:border-red-500/30",
          btnColor: "bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white",
          activePin: "bg-red-500"
        };
      case "emerald_slate":
        return {
          bgGrad: "from-emerald-500/10 via-black/40 to-transparent",
          border: "border-emerald-500/20",
          textAccent: "text-emerald-400",
          bgAccent: "bg-emerald-500/10",
          textBranding: "text-emerald-500",
          borderHover: "hover:border-emerald-500/30",
          btnColor: "bg-gradient-to-r from-emerald-400 to-[#10B981] hover:from-emerald-500 hover:to-[#059669] text-black",
          activePin: "bg-[#10B981]"
        };
      case "golden_trophy":
        return {
          bgGrad: "from-yellow-500/10 via-black/40 to-transparent",
          border: "border-yellow-500/20",
          textAccent: "text-yellow-400",
          bgAccent: "bg-yellow-500/10",
          textBranding: "text-yellow-500",
          borderHover: "hover:border-yellow-500/30",
          btnColor: "bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black",
          activePin: "bg-yellow-500"
        };
      case "cosmic_orange":
      default:
        return {
          bgGrad: "from-orange-500/10 via-black/40 to-transparent",
          border: "border-orange-500/20",
          textAccent: "text-orange-400",
          bgAccent: "bg-orange-500/10",
          textBranding: "text-orange-500",
          borderHover: "hover:border-orange-500/30",
          btnColor: "bg-gradient-to-r from-orange-400 to-amber-500 hover:from-orange-500 hover:to-amber-600 text-black",
          activePin: "bg-orange-500"
        };
    }
  }, [customTexts.themeStyle]);

  // Dynamically sort the active slips based on current administrator criteria
  const sortedSlips = React.useMemo(() => {
    const list = [...slipsStates];
    const rule = customTexts.slipsSorting || "countdown";
    if (rule === "odds_desc") {
      return [...list].sort((a, b) => b.odds - a.odds);
    } else if (rule === "cost_asc") {
      return [...list].sort((a, b) => a.cost - b.cost);
    } else if (rule === "newest") {
      return [...list].reverse();
    } else {
      // Default rule: countdown (expiresInSecs soonest first)
      return [...list].sort((a, b) => {
        if (a.expiresInSecs === 0) return 1;
        if (b.expiresInSecs === 0) return -1;
        return a.expiresInSecs - b.expiresInSecs;
      });
    }
  }, [slipsStates, customTexts.slipsSorting]);

  // Countdown timer logic
  useEffect(() => {
    const interval = setInterval(() => {
      setSlipsStates(prev => prev.map(slip => ({
        ...slip,
        expiresInSecs: Math.max(0, slip.expiresInSecs - 1)
      })));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync unlocked slips from local and profile
  useEffect(() => {
    const saved = localStorage.getItem(`unlocked_slips_${profile.uid}`);
    if (saved) {
      setUnlockedIds(JSON.parse(saved));
    }
  }, [profile.uid]);

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}h ${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  };

  const handleOpenSlip = (slip: Betslip) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    if (unlockedIds.includes(slip.id)) {
      // Already unlocked
      setModalSlip(slip);
      return;
    }
    // Prompt to unlock
    setModalSlip(slip);
  };

  const confirmUnlockSlip = async () => {
    if (!modalSlip) return;
    setErrorMsg(null);
    setSuccessMsg(null);

    // If already unlocked
    if (unlockedIds.includes(modalSlip.id)) {
      setModalSlip(null);
      return;
    }

    if (profile.balance < modalSlip.cost) {
      setErrorMsg(`Salio lako halitoshi ku-unlock mkeka huu! Unahitaji TZS ${modalSlip.cost.toLocaleString()}. Tafadhali ongeza salio (Weka Pesa) kwanza.`);
      return;
    }

    setLoadingSlipId(modalSlip.id);
    try {
      // Deduct balance
      const newBalance = profile.balance - modalSlip.cost;
      await updateDoc(doc(db, 'users', profile.uid), {
        balance: newBalance
      });
      
      // Save unlocked list locally
      const updatedList = [...unlockedIds, modalSlip.id];
      setUnlockedIds(updatedList);
      localStorage.setItem(`unlocked_slips_${profile.uid}`, JSON.stringify(updatedList));

      // Append standard notifications logs
      const logId = 'log-unlock-' + Math.random().toString(36).substring(2, 9);
      await setDoc(doc(db, 'notifications', logId), {
        id: logId,
        userId: profile.uid,
        title: `${modalSlip.bookmaker} Slip Unlocked!`,
        message: `Umekamilisha kufungua mkeka wa ${modalSlip.bookmaker} wenye odds ${modalSlip.odds} kwa mafanikio.`,
        type: 'general',
        read: false,
        createdAt: new Date().toISOString()
      });

      setSuccessMsg("Hongera! Mkeka umereveliwa kikamilifu! ✨");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to unlock slip");
    } finally {
      setLoadingSlipId(null);
    }
  };

  const isWhiteBg = customTexts?.whiteThemeMode === 'enabled';

  return (
    <div className="space-y-6">

      {/* Dynamic Welcome Heading and Subtitle managed by Admin ("Kisha admin aedit kila kitu mandishi yote") */}
      <div className={`space-y-1 border p-5 rounded-3xl text-left transition-all ${
        isWhiteBg 
          ? 'bg-white border-black/10 text-black shadow-md' 
          : `bg-white/[0.01] border ${theme.border} text-white`
      }`}>
        <h1 className={`text-xl font-extrabold uppercase tracking-tight flex items-center gap-2 ${isWhiteBg ? 'text-black' : 'text-white'}`}>
          <span>{customTexts.welcomeTitle}</span>
          <span className={`${theme.textAccent} text-sm font-normal px-2 py-0.5 ${theme.bgAccent} border ${theme.border} rounded-md uppercase font-mono`}>By {customTexts.providerName}</span>
        </h1>
        <p className={`text-[11px] leading-relaxed font-mono ${isWhiteBg ? 'text-black/60' : 'text-white/50'}`}>
          {customTexts.welcomeSubtitle}
        </p>
      </div>
      
      {/* Home Hero Account Banner */}
      <div className={`border p-5 rounded-3xl flex justify-between items-center glass transition-all ${
        isWhiteBg
          ? 'bg-white border-black/10 text-black shadow-md'
          : `bg-gradient-to-tr ${theme.bgGrad} border ${theme.border} text-white`
      }`}>
        <div>
          <span className={`text-[10px] uppercase font-mono tracking-wider ${isWhiteBg ? 'text-black/50' : 'text-white/40'}`}>Aina ya Hali:</span>
          <h2 className={`text-xl font-black font-mono mt-0.5 ${isWhiteBg ? 'text-black' : 'text-white'}`}>
            Kiwango {profile.level} VIP
          </h2>
          <p className={`text-[9px] ${theme.textAccent} font-mono mt-0.5 uppercase tracking-tight`}>
            Mwanachama wa Kipekee (Premium Member)
          </p>
        </div>
        
        <div className={`flex items-center gap-1 text-[9px] font-black ${theme.textAccent} ${theme.bgAccent} border ${theme.border} px-2.5 py-1 rounded-full uppercase font-mono`}>
          <span>{customTexts.providerName}</span>
          <div className={`w-2.5 h-2.5 rounded-full ${theme.activePin} shrink-0 animate-pulse`} />
        </div>
      </div>

      {/* Premium Notification Banner if specified */}
      {customTexts.premiumPromo && (
        <div className={`px-5 py-3 ${theme.bgAccent} border ${theme.border} rounded-2xl flex items-center gap-2.5 ${theme.textAccent} text-[10px] font-mono`}>
          <span className="text-sm">💡</span>
          <span>{customTexts.premiumPromo}</span>
        </div>
      )}

      {/* Picture layout replication: Active Betslips Title Bar with countbadge */}
      <div className="flex justify-between items-center px-1">
        <h2 className={`text-base font-black uppercase tracking-tight flex items-center gap-1.5 font-mono ${isWhiteBg ? 'text-black' : 'text-white'}`}>
          🔥 {customTexts.premiumHeader}
        </h2>
        <span className={`inline-flex items-center gap-1 text-[10px] px-2.5 py-0.5 ${theme.bgAccent} ${theme.textAccent} border ${theme.border} rounded-full font-extrabold uppercase`}>
          <span className={`w-1.5 h-1.5 ${theme.activePin} rounded-full animate-ping`} />
          {sortedSlips.length} Active
        </span>
      </div>

      {/* Betslips list cards - fully supports dynamic list-to-grid grid-cols and layout swaps */}
      <div className={customTexts.slipsLayout === 'two_columns' ? "grid grid-cols-1 sm:grid-cols-2 gap-4" : "space-y-4"}>
        {sortedSlips.map((slip) => {
          const isUnlocked = unlockedIds.includes(slip.id);
          
          return (
            <div 
              key={slip.id} 
              onClick={() => handleOpenSlip(slip)}
              className={`rounded-[22px] p-5 shadow-2xl relative overflow-hidden group transition-all duration-300 cursor-pointer active:scale-[0.99] ${
                isWhiteBg 
                  ? 'bg-white border border-black/10 hover:border-black/20 text-black' 
                  : `bg-[#0F1116] border border-white/10 ${theme.borderHover} text-white`
              }`}
            >
              
              {/* Slip header with bookmaker emblem */}
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white text-xs relative ${
                    slip.bookmaker === 'SportyBet' ? 'bg-[#E31C24]' : 'bg-[#7BB31A]'
                  }`}>
                    {slip.bookmaker === 'SportyBet' ? 'S' : 'bP'}
                    <span className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full p-0.5 border border-black text-white shadow-md">
                      <Check className="w-2 h-2 stroke-[4]" />
                    </span>
                  </div>
                  <div>
                    <h3 className={`text-xs font-bold uppercase tracking-wide flex items-center gap-1 ${isWhiteBg ? 'text-black' : 'text-white'}`}>
                      {slip.bookmaker}
                      <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3.5] bg-emerald-500/15 p-0.5 rounded-full inline shrink-0" />
                    </h3>
                    <p className={`text-[10px] font-mono ${isWhiteBg ? 'text-black/50' : 'text-white/50'}`}>by {slip.provider}</p>
                    <div className="mt-1 flex gap-1 font-mono">
                      {slip.status === 'won' && (
                        <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black rounded-md uppercase tracking-wider border border-emerald-500/30 flex items-center gap-0.5 animate-pulse">
                          ✅ Tiki Umetiki
                        </span>
                      )}
                      {slip.status === 'lost' && (
                        <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[8px] font-black rounded-md uppercase tracking-wider border border-red-500/30 flex items-center gap-0.5">
                          ❌ Lost
                        </span>
                      )}
                      {(!slip.status || slip.status === 'active') && (
                        <span className="px-1.5 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] font-bold rounded-md uppercase tracking-wider border border-blue-500/20 flex items-center gap-0.5">
                          ⏳ Active
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Rating flag */}
                <span className={`inline-flex items-center gap-1 text-[8.5px] px-2 py-0.5 ${theme.bgAccent} ${theme.textAccent} border ${theme.border} rounded-lg uppercase tracking-wide font-black`}>
                  {slip.accuracy}
                </span>
              </div>

              {/* Odds, Stake, Expires grid */}
              <div className={`grid grid-cols-3 gap-2.5 py-3 px-4 rounded-xl font-mono text-center mb-4 text-[10px] ${
                isWhiteBg ? 'bg-black/5 border border-black/5' : 'bg-black/35 border border-white/5'
              }`}>
                <div>
                  <span className={`block text-[8px] uppercase font-black ${isWhiteBg ? 'text-black/45' : 'text-white/30'}`}>ODDS</span>
                  <span className={`text-[#22C55E] text-sm font-black tracking-tight`}>{slip.odds.toFixed(2)}</span>
                </div>
                <div>
                  <span className={`block text-[8px] uppercase font-black ${isWhiteBg ? 'text-black/45' : 'text-white/30'}`}>STAKE</span>
                  <span className={`text-sm font-bold ${isWhiteBg ? 'text-black' : 'text-white'}`}>TZS {slip.stake.toLocaleString()}</span>
                </div>
                <div>
                  <span className={`block text-[8px] uppercase font-black ${isWhiteBg ? 'text-black/45' : 'text-white/30'}`}>EXPIRES IN</span>
                  <span 
                    style={customTexts.matchTimeColor ? { color: customTexts.matchTimeColor } : {}}
                    className={`text-sm font-black tracking-tight flex items-center justify-center gap-1 ${
                      customTexts.matchTimeColor ? '' : theme.textAccent
                    }`}
                  >
                    <Clock className="w-3 h-3 animate-pulse" /> {formatTime(slip.expiresInSecs)}
                  </span>
                </div>
              </div>

              {/* View / Purchase CTA Button */}
              <div className="flex justify-between items-center gap-3">
                <div className={`text-[9px] font-mono leading-tight ${isWhiteBg ? 'text-black/60' : 'text-white/40'}`}>
                  {isUnlocked ? (
                    <span className="text-emerald-400 font-bold uppercase flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 shrink-0" /> ACCESSIBLE
                    </span>
                  ) : (
                    <span>Uhakiki automatically na PesaPal</span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handleOpenSlip(slip)}
                  className={`py-2.5 px-5 ${theme.btnColor} font-black text-xs rounded-full uppercase tracking-wider flex items-center gap-1 active:scale-95 transition-all cursor-pointer shadow-lg`}
                >
                  View Betslip →
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Embedded interactive slide view prediction tips modal */}
      {modalSlip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className={`w-full max-w-sm rounded-[30px] p-6 space-y-5 shadow-2xl relative font-sans animate-fade-in text-xs ${
            isWhiteBg ? 'bg-white border border-black/10 text-black' : 'bg-[#0E1116] border border-white/10 text-white'
          }`}>
            
            <div className={`flex justify-between items-start border-b pb-2 ${isWhiteBg ? 'border-black/5' : 'border-white/5'}`}>
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-md flex items-center justify-center font-bold text-white text-[10px] relative ${
                  modalSlip.bookmaker === 'SportyBet' ? 'bg-[#E31C24]' : 'bg-[#7BB31A]'
                }`}>
                  {modalSlip.bookmaker === 'SportyBet' ? 'S' : 'bP'}
                  <span className="absolute -bottom-0.5 -right-0.5 bg-emerald-500 rounded-full p-px border border-black text-white shadow-sm">
                    <Check className="w-1.5 h-1.5 stroke-[4]" />
                  </span>
                </div>
                <div className="flex flex-col">
                  <h3 className={`text-xs font-black uppercase tracking-wider flex items-center gap-1 ${isWhiteBg ? 'text-black' : 'text-white'}`}>
                    {modalSlip.bookmaker} Betslip Slip
                    <Check className="w-3 h-3 text-emerald-400 stroke-[4] bg-emerald-500/10 rounded-full p-px shrink-0" />
                  </h3>
                  <div className="mt-0.5 flex gap-1 font-mono">
                    {modalSlip.status === 'won' && (
                      <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black rounded uppercase tracking-wider border border-emerald-500/30 flex items-center gap-0.5 animate-pulse">
                        ✅ Tiki Umetiki
                      </span>
                    )}
                    {modalSlip.status === 'lost' && (
                      <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[8px] font-black rounded uppercase tracking-wider border border-red-500/30 flex items-center gap-0.5">
                        ❌ Lost
                      </span>
                    )}
                    {(!modalSlip.status || modalSlip.status === 'active') && (
                      <span className="px-1.5 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] font-bold rounded uppercase tracking-wider border border-blue-500/20 flex items-center gap-0.5">
                        ⏳ Active
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <button 
                onClick={() => { setModalSlip(null); setErrorMsg(null); setSuccessMsg(null); }}
                className={`px-2 py-0.5 rounded font-mono text-[9px] uppercase ${
                  isWhiteBg ? 'bg-black/5 text-black hover:bg-black/10' : 'bg-white/5 text-white/40 hover:text-white'
                }`}
              >
                Funga
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl flex gap-1.5 font-mono text-[10px]">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl flex gap-1.5 font-mono text-[10px]">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* If unlocked, show codes & match items */}
            {unlockedIds.includes(modalSlip.id) ? (
              <div className="space-y-4 animate-fade-in font-mono">
                
                {/* Booking Code Display Box */}
                <div className="bg-black/40 border border-emerald-500/30 p-4 rounded-xl text-center space-y-2.5">
                  <span className="text-[9px] text-[#22C55E] uppercase font-black tracking-widest block">BOOKING BOOKMAKER CODE:</span>
                  <p className="text-xl font-black text-white uppercase tracking-wide select-all bg-emerald-500/5 py-1 px-3.5 border border-emerald-500/10 rounded inline-block">
                    {modalSlip.bookingCode}
                  </p>
                  <span className="block text-[8px] text-white/45">akili na uweke kwenye programu ya {modalSlip.bookmaker}!</span>
                </div>

                {/* Selections game listings */}
                <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
                  <span className="text-[10px] text-white/40 uppercase font-black border-b border-white/5 pb-1 block">Mech and Picks selected:</span>
                  {modalSlip.games.map((g, idx) => (
                    <div key={idx} className="p-2 bg-white/[0.02] border border-white/5 rounded-xl flex justify-between items-center text-[11px]">
                      <div>
                        <p className="font-bold text-white truncate max-w-[190px]">{g.match}</p>
                        <p className="text-[10px] text-[#FB923C] font-black">{g.prediction}</p>
                      </div>
                      <span className="text-[#22C55E] font-black">{g.odds.toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => { setModalSlip(null); }}
                  className="w-full py-2.5 bg-orange-500 hover:bg-orange-400 text-black font-black uppercase text-[10px] rounded-xl"
                >
                  NIMEFAHAMU, SAWA
                </button>

              </div>
            ) : (
              /* ONE SINGLE SIMPLIFIED AUTOMATED CHECKOUT SECTION ("kwenye malipo weka sehemu moja tu automatically") */
              <div className="space-y-4 font-mono text-left">
                <div className="p-3 bg-black/45 border-2 border-orange-500/20 rounded-2xl text-center">
                  <span className="text-[9px] text-white/50 font-mono uppercase block">Gharama ya Mkeka:</span>
                  <p className="text-base font-black text-[#FB923C] font-mono">TZS {modalSlip.cost.toLocaleString()}</p>
                </div>

                {checkoutStep === 'select' ? (
                  <form onSubmit={handlePesapalDirectPay} className="space-y-3.5">
                    <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl space-y-1 text-center">
                      <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center justify-center gap-1">
                        <Zap className="w-3.5 h-3.5 animate-pulse" /> MALIPO CHA CHAKO AUTOMATIC (PesaPal)
                      </p>
                      <p className="text-[9.5px] text-white/60">
                        Weka namba ya simu au barua pepe yako ili kukamilisha malipo na kufungua mkeka huu papo hapo kiotomatiki!
                      </p>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] text-white/40 uppercase font-black">Namba ya Simu au Email</label>
                      <input
                        type="text"
                        value={paymentIdentifier}
                        onChange={(e) => setPaymentIdentifier(e.target.value)}
                        placeholder="Mifano: 07xxxxxxxx au mteja@gmail.com"
                        className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-xl text-white text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={pesapalLoading}
                      className="w-full py-3 bg-orange-500 hover:bg-orange-400 text-black font-black text-xs uppercase rounded-xl flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer shadow-lg shadow-orange-500/10"
                    >
                      {pesapalLoading ? "Tunajiandaa..." : "Endelea na Lipia Kiotomatiki"} <ArrowRight className="w-4 h-4" />
                    </button>

                    {/* Secondary Account VIP Checkout Toggle to preserve utility */}
                    <div className="pt-2 text-center border-t border-white/5">
                      <button
                        type="button"
                        onClick={confirmUnlockSlip}
                        disabled={payByBalanceLoading}
                        className="text-[9.5px] text-white/40 hover:text-orange-400 transition underline cursor-pointer uppercase font-bold"
                      >
                        {payByBalanceLoading ? "Inapakia..." : "Njia Mbadala ya Haraka"}
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-3.5">
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl space-y-1">
                      <p className="text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                        <ShieldCheck className="w-4 h-4 animate-bounce" /> LANGO LA MALIPO LIKO TAYARI
                      </p>
                      <p className="text-[9.5px] text-white/70">
                        Kamilisha malipo yako kupitia mfumo salama wa PesaPal hapa chini. Mkeka wako utafunguliwa <strong className="text-emerald-400">kiotomatiki papo hapo</strong> mara baada ya kukamilisha malipo!
                      </p>
                    </div>

                    <div className="relative w-full rounded-2xl border border-white/10 overflow-hidden bg-white shadow-2xl">
                      {redirectUrl && (
                        <iframe 
                          src={redirectUrl} 
                          className="w-full h-[320px] bg-white border-0" 
                          allow="payment"
                          title="PesaPal checkout"
                        />
                      )}
                    </div>

                    <div className="text-center pt-1">
                      <button
                        type="button"
                        onClick={() => { setCheckoutStep('select'); setRedirectUrl(null); }}
                        className="text-[9.5px] text-white/40 hover:text-red-400 hover:underline transition uppercase font-bold py-1 cursor-pointer"
                      >
                        ← Ghairi & Rudi Nyuma (Ghairi Malipo)
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
