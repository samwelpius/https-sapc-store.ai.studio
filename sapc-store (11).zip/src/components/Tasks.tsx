import React, { useState, useEffect } from 'react';
import { db, handleFirestoreError, OperationType, collection, doc, setDoc, updateDoc, getDocs, query, where, increment, limit } from '../supabase';
import { UserProfile, INVESTMENT_LEVELS, VideoTask, TaskCompletion } from '../types';
import { 
  Play, CheckCircle2, Award, Clock, AlertCircle, Sparkles, HelpCircle, ArrowRight,
  Tv, Compass, HelpCircle as HelpIcon, Trophy, MessageSquare
} from 'lucide-react';

interface TasksProps {
  profile: UserProfile;
  onRefreshProfile: () => void;
}

export default function Tasks({ profile, onRefreshProfile }: TasksProps) {
  // Task core state
  const [completionsToday, setCompletionsToday] = useState<any[]>([]);
  const [allVideos, setAllVideos] = useState<VideoTask[]>([]);
  
  const [activeVideo, setActiveVideo] = useState<VideoTask | null>(null);
  const [videoTimer, setVideoTimer] = useState(0);
  const [isWatching, setIsWatching] = useState(false);
  
  // Quiz Task State
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizAnswer_1, setQuizAnswer_1] = useState('');
  const [quizAnswer_2, setQuizAnswer_2] = useState('');

  // Daily Prediction State
  const [footballPredHome, setFootballPredHome] = useState('');
  const [footballPredAway, setFootballPredAway] = useState('');
  const [footballSubmitted, setFootballSubmitted] = useState(false);

  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];
  const maxTasksToday = INVESTMENT_LEVELS[profile.level || 0].tasksCount;
  const completedCountToday = completionsToday.length;
  const remainingTasksCount = Math.max(0, maxTasksToday - completedCountToday);

  // Load daily tasks completed today and video definitions from Firestore
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Today completions
        const compQuery = query(
          collection(db, 'completions'),
          where('userId', '==', profile.uid),
          where('date', '==', todayStr)
        );
        const compSnap = await getDocs(compQuery);
        setCompletionsToday(compSnap.docs.map(doc => doc.data()));

        // Available videos
        const vidSnap = await getDocs(collection(db, 'videos'));
        const vids = vidSnap.docs.map(doc => doc.data() as VideoTask);
        
        // If empty, generate a few default ones
        if (vids.length === 0) {
          const defaultVids: VideoTask[] = [
            {
              id: 'vid-1',
              title: 'Jinsi ya Kuwekeza na SAPC Store App',
              videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
              rewardAmount: 500,
              duration: 12,
              active: true,
              createdAt: new Date().toISOString()
            },
            {
              id: 'vid-2',
              title: 'SAPC STORE - Maisha na Uhuru wa Kifedha',
              videoUrl: 'https://www.w3schools.com/html/movie.mp4',
              rewardAmount: 500,
              duration: 10,
              active: true,
              createdAt: new Date().toISOString()
            },
            {
              id: 'vid-3',
              title: 'Siri ya Mafanikio ya Predictor AI SAPC',
              videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
              rewardAmount: 500,
              duration: 15,
              active: true,
              createdAt: new Date().toISOString()
            }
          ];
          setAllVideos(defaultVids);
        } else {
          setAllVideos(vids.filter(v => v.active));
        }
      } catch (err) {
        console.error("Error fetching tasks configs:", err);
      } finally {
        setLoading(false);
      }
    };

    if (profile.uid) {
      fetchData();
    }
  }, [profile.uid, todayStr]);

  // Handle video watching counter
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isWatching && videoTimer > 0) {
      interval = setInterval(() => {
        setVideoTimer(prev => prev - 1);
      }, 1000);
    } else if (isWatching && videoTimer === 0) {
      setIsWatching(false);
      handleCompleteVideoTask();
    }
    return () => clearInterval(interval);
  }, [isWatching, videoTimer]);

  const startWatchingVideo = (video: VideoTask) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (profile.level === 0 && profile.role !== 'admin') {
      setErrorMsg("Kazi zote zimefungwa! Wasiliana na admin au nenda kuboresha akaunti yako kuwa Kiwango 1 kwanza.");
      return;
    }

    // Limit check
    if (completedCountToday >= maxTasksToday) {
      setErrorMsg(`Umekamilisha kikomo chako cha kazi leo! Kiwango chako hukuruhusu kufanya kazi ${maxTasksToday} kwa Siku pekee. Tafadhali boresha kiwango kwa kipato kikubwa zaidi!`);
      return;
    }

    // Check if user already saw this specific video today
    const alreadyDone = completionsToday.some(c => c.taskId === video.id);
    if (alreadyDone) {
      setErrorMsg("Tayari umeshaangalia na kulipwa kwa video hii leo! Jaribu video nyingine.");
      return;
    }

    setActiveVideo(video);
    setVideoTimer(video.duration);
    setIsWatching(true);
  };

  const handleCompleteVideoTask = async () => {
    if (!activeVideo) return;
    setLoading(true);

    try {
      const reward = activeVideo.rewardAmount;
      const compId = 'comp-' + Math.random().toString(36).substring(2, 10);
      
      const newCompletion: TaskCompletion = {
        id: compId,
        userId: profile.uid,
        taskType: 'video',
        taskId: activeVideo.id,
        reward: reward,
        date: todayStr,
        completedAt: new Date().toISOString()
      };

      // 1. Save Completion log to DB
      await setDoc(doc(db, 'completions', compId), newCompletion);

      // 2. Add reward as points instead of direct wallet balance
      await updateDoc(doc(db, 'users', profile.uid), {
        points: increment(reward),
        totalPoints: increment(reward)
      });

      // 3. Keep local state updated
      setCompletionsToday(prev => [...prev, newCompletion]);
      setSuccessMsg(`Hongera mno! Umetazama video hadi mwisho na kupata Points ${reward.toLocaleString()}! Unaweza kubadilisha points hizi kuwa pesa katika Salio Kuu hapa chini.`);
      setActiveVideo(null);
      onRefreshProfile();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `completions/${activeVideo.id}`);
    } finally {
      setLoading(false);
    }
  };

  const handleConvertPointsToBalance = async () => {
    const pointsToConvert = Number(profile.points || 0);
    if (pointsToConvert <= 0) return;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      // 1. Convert points to balance: add points value to balance and totalEarnings, clear points
      await updateDoc(doc(db, 'users', profile.uid), {
        balance: increment(pointsToConvert),
        totalEarnings: increment(pointsToConvert),
        points: 0
      });

      // 2. Add an activity log transaction
      const transId = 'trans-conv-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', transId), {
        id: transId,
        userId: profile.uid,
        username: profile.username,
        email: profile.email,
        type: 'points_conversion',
        amount: pointsToConvert,
        message: `Mtumiaji amebadilisha Points ${pointsToConvert.toLocaleString()} kuwa Shilingi TZS ${pointsToConvert.toLocaleString()} za kitanzania kwenye Wallet kuu!`,
        createdAt: new Date().toISOString()
      });

      setSuccessMsg(`Hongera! Umefanikiwa kubadilisha Points ${pointsToConvert.toLocaleString()} kuwa Salio la TZS ${pointsToConvert.toLocaleString()}! Pesa imeongezwa kwenye akaunti yako kuu.`);
      onRefreshProfile();
    } catch (err) {
      console.error('Points conversion error: ', err);
      setErrorMsg('Imeshindikana kubadilisha points. Tafadhali jaribu tena.');
    } finally {
      setLoading(false);
    }
  };

  // 4. Bonus Task: Click to claim
  const handleClaimBonusTask = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (profile.level === 0 && profile.role !== 'admin') {
      setErrorMsg("Kazi zote zimefungwa! Wasiliana na admin au nenda kuboresha akaunti yako kuwa Kiwango 1 kwanza.");
      return;
    }

    if (completedCountToday >= maxTasksToday) {
      setErrorMsg(`Umekamilisha kikomo chako cha kazi leo (Kikomo: ${maxTasksToday} kwa siku)!`);
      return;
    }

    // Check if bonus claimed today
    const bonusClaimed = completionsToday.some(c => c.taskType === 'bonus');
    if (bonusClaimed) {
      setErrorMsg("Tayari umeshaomba bonasi yako leo! Karibu kesho.");
      return;
    }

    setLoading(true);
    try {
      const reward = 300; // TZS 300 bonus
      const compId = 'comp-bonus-' + Math.random().toString(36).substring(2, 10);
      
      const newCompletion: TaskCompletion = {
        id: compId,
        userId: profile.uid,
        taskType: 'bonus',
        taskId: 'daily-bonus-300',
        reward: reward,
        date: todayStr,
        completedAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'completions', compId), newCompletion);
      await updateDoc(doc(db, 'users', profile.uid), {
        balance: increment(reward),
        totalEarnings: increment(reward)
      });

      setCompletionsToday(prev => [...prev, newCompletion]);
      setSuccessMsg(`Hongera! TZS ${reward} zimeongezwa kwenye salio lako kama Bonus ya Siku!`);
      onRefreshProfile();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 5. Survey / Survey Task Submit
  const handleSurveySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (profile.level === 0 && profile.role !== 'admin') {
      setErrorMsg("Kazi zote zimefungwa! Wasiliana na admin au nenda kuboresha akaunti yako kuwa Kiwango 1 kwanza.");
      return;
    }

    if (completedCountToday >= maxTasksToday) {
      setErrorMsg(`Ushajaza kikomo chako cha kazi leo!`);
      return;
    }

    const surveyClaimed = completionsToday.some(c => c.taskType === 'survey');
    if (surveyClaimed) {
      setErrorMsg("Tayari umeshajaza na kukamilisha utafiti (Survey Task) ya leo.");
      return;
    }

    if (!quizAnswer_1 || !quizAnswer_2) {
      setErrorMsg("Tafadhali jibu maswali yote mawili.");
      return;
    }

    setLoading(true);
    try {
      const reward = 400; // TZS 400
      const compId = 'comp-survey-' + Math.random().toString(36).substring(2, 10);
      
      const newCompletion: TaskCompletion = {
        id: compId,
        userId: profile.uid,
        taskType: 'survey',
        taskId: 'survey-satisfaction',
        reward: reward,
        date: todayStr,
        completedAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'completions', compId), newCompletion);
      await updateDoc(doc(db, 'users', profile.uid), {
        balance: increment(reward),
        totalEarnings: increment(reward)
      });

      setCompletionsToday(prev => [...prev, newCompletion]);
      setQuizSubmitted(true);
      setSuccessMsg(`Hongera! Utafiti wako umepokelewa na umelipwa TZS ${reward}!`);
      onRefreshProfile();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Progress Banner displaying limits */}
      <div className="bg-white/[0.03] border border-white/10 p-5 rounded-2xl flex justify-between items-center glass bg-gradient-to-br from-[#0A0A0C] to-white/[0.02]">
        <div>
          <h2 className="text-base font-extrabold text-[#FB923C] flex items-center gap-1.5 uppercase tracking-wide">
            Kazi za Leo <Trophy className="w-4 h-4 text-orange-400" />
          </h2>
          <p className="text-xs text-white/60 font-mono">
            Kiwango {profile.level}: Kamilisha kazi upate mapato makubwa!
          </p>
          <div className="mt-2 flex items-center gap-1">
            <span className="text-[10px] text-white/40 font-mono">Maendeleo ya Leo:</span>
            <span className="text-xs font-bold text-orange-400 font-mono">{completedCountToday} / {maxTasksToday}</span>
            <span className="text-[10px] text-white/40 font-mono">kukamilika</span>
          </div>
        </div>
        
        {/* Dynamic visual rings / percentage */}
        <div className="relative flex items-center justify-center w-14 h-14 rounded-full bg-black/40 border-2 border-orange-500 accent-glow">
          <div className="text-center">
            <span className="text-xs font-extrabold text-orange-400 font-mono">
              {maxTasksToday > 0 ? Math.round((completedCountToday / maxTasksToday) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* POINTS WALLET AND CONVERSION CARD */}
      <div className="bg-gradient-to-r from-orange-950/20 to-black border border-orange-500/30 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 glass relative overflow-hidden accent-glow">
        <div className="space-y-1 z-10">
          <p className="text-[10px] font-bold text-orange-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
            <Award className="w-4 h-4" /> WALLET YA POINTS (WATCH-TO-EARN)
          </p>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">
              {(profile.points || 0).toLocaleString()}
            </span>
            <span className="text-xs text-orange-400 font-bold uppercase tracking-wider">Points</span>
          </div>
          <p className="text-[10px] text-white/50 font-mono">
            Kiwango cha Ubadilishaji: <span className="text-white font-bold">1 Point = 1 TZS (Sawa na Shilingi Moja)</span>
          </p>
        </div>

        <button
          onClick={handleConvertPointsToBalance}
          disabled={loading || !(profile.points && profile.points > 0)}
          id="btn-convert-points"
          className={`py-3 px-5 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all active:scale-95 z-10 ${
            (profile.points && profile.points > 0)
              ? 'bg-gradient-to-r from-orange-400 to-amber-500 text-black hover:opacity-95 cursor-pointer shadow-md shadow-orange-500/20'
              : 'bg-white/5 text-white/30 cursor-not-allowed border border-white/10'
          }`}
        >
          <Sparkles className="w-4 h-4" /> Badili Points Kuwa Pesa (TZS)
        </button>
      </div>

      {errorMsg && (
        <div className="flex items-start p-3 text-sm rounded bg-red-500/10 border border-red-500/20 text-red-400 gap-2 font-mono">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="flex items-start p-3 text-sm rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 gap-2 font-mono">
          <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* active video player segment */}
      {activeVideo && (
        <div className="bg-[#0A0A0C] border-2 border-orange-500 p-5 rounded-3xl space-y-4 animate-pulse glass accent-glow">
          <div className="flex justify-between items-center border-b border-white/10 pb-2">
            <p className="text-xs font-bold text-orange-400 flex items-center gap-1 uppercase tracking-wider font-mono">
              Anza Kutazama (Watching rewarded active) <Clock className="w-3.5 h-3.5" />
            </p>
            <span className="text-xs font-black text-rose-500 font-mono">{videoTimer} Sec za kubaki</span>
          </div>
          <h3 className="font-extrabold text-white text-sm">{activeVideo.title}</h3>
          
          {/* Mock Player UI with beautiful visuals */}
          <div className="relative aspect-video rounded-2xl bg-black overflow-hidden border border-white/10 flex flex-col items-center justify-center space-y-2">
            <video 
              src={activeVideo.videoUrl} 
              autoPlay 
              muted 
              className="absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none"
            />
            {isWatching ? (
              <div className="z-10 text-center space-y-1 bg-black/80 p-3 rounded-xl border border-white/10">
                <p className="text-xs font-extrabold text-white">Video inacheza... Tafadhali usifunge dirisha hili</p>
                <p className="text-[10px] text-white/40 font-mono">Mwishoni mwa video utapokea TZS {activeVideo.rewardAmount} papo hapo!</p>
              </div>
            ) : (
              <p className="text-xs text-white/40 z-10 font-bold">Inapakia video...</p>
            )}

            {/* Custom Progress bar */}
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-[#0A0A0C]">
              <div 
                className="h-full bg-orange-500 transition-all duration-1000"
                style={{ width: `${((activeVideo.duration - videoTimer) / activeVideo.duration) * 100}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 2. TASK TYPES GRID */}
      <div className="space-y-4">
        {profile.level === 0 && profile.role !== 'admin' ? (
          <div className="bg-white/[0.02] border-2 border-orange-500/10 p-6 rounded-3xl text-center space-y-4 shadow-xl glass relative overflow-hidden">
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-orange-500/5 rounded-full filter blur-xl pointer-events-none"></div>
            <div className="py-6 space-y-3 max-w-sm mx-auto">
              <div className="w-14 h-14 bg-red-400/10 border border-red-500/20 text-red-400 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                <AlertCircle className="w-8 h-8 animate-bounce text-orange-400" />
              </div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider font-mono">
                KAZI ZIMEFUNGWA ! (LOCK)
              </h3>
              <p className="text-xs text-white/60 leading-relaxed font-sans">
                Ili uanze kufanya kazi, kutazama video zetu za matangazo, na kupokea bonus, lazima kwanza ujiunge na kikundi cha uwekezaji kuanzia <strong className="text-orange-400 font-bold uppercase">Kiwango 1 (Mtaji: TZS 6,500)</strong> au kuendelea.
              </p>
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 text-[9px] text-white/40 font-mono leading-relaxed">
                Mwanachama wa Bure (Kiwango 0) hawezi kufanya miamala wala kazi. Admins tu wanaweza kufanya majaribio bure bila kikwazo.
              </div>
              <div className="pt-2">
                <p className="text-[10px] text-orange-400 font-bold font-mono">
                  Bofya kitufe cha "Kiwango 0" hapo juu kuboresha akaunti yako kwanza kabla ya kufanya kazi!
                </p>
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Type A: Video rewarded tasks list */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-white/40 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Tv className="w-4 h-4 text-orange-400" /> Kazi za Tazama Video (Video rewarded Tasks)
              </h3>
              <div className="space-y-2">
                {allVideos.map((vid) => {
                  const isDone = completionsToday.some(c => c.taskId === vid.id);
                  return (
                    <div key={vid.id} className="bg-white/[0.02] p-4 rounded-2xl border border-white/10 flex justify-between items-center glass">
                      <div className="space-y-1">
                        <p className={`text-sm font-extrabold ${isDone ? 'text-white/30 line-through' : 'text-white'}`}>
                          {vid.title}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-white/40">
                          <span className="flex items-center gap-0.5 text-orange-400 font-bold font-mono">
                            TZS {vid.rewardAmount.toLocaleString()}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5 font-mono">
                            <Clock className="w-3 h-3" /> {vid.duration}s
                          </span>
                        </div>
                      </div>

                      <button
                        disabled={isDone || isWatching || completedCountToday >= maxTasksToday}
                        onClick={() => startWatchingVideo(vid)}
                        className={`p-2.5 rounded-xl transition ${
                          isDone 
                            ? 'bg-white/5 border border-white/5 text-white/20' 
                            : 'bg-orange-500 hover:bg-orange-400 text-black font-bold shadow-md shadow-orange-500/10 active:scale-95'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-4.5 h-4.5" /> : <Play className="w-4.5 h-4.5 fill-current" />}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Type B: Survey tasks section */}
            <div className="bg-white/[0.02] border border-white/10 p-5 rounded-2xl space-y-4 glass">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono flex items-center gap-1.5 border-b border-white/5 pb-2">
                <MessageSquare className="w-4 h-4 text-orange-450 text-orange-450" /> Kazi ya Utafiti (Survey Task)
              </h3>
              
              {completionsToday.some(c => c.taskType === 'survey') ? (
                <div className="text-center py-4 space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-orange-400 mx-auto" />
                  <p className="text-xs text-orange-400 font-bold">Umekamilisha Utafiti (Survey) Yako Leo!</p>
                  <p className="text-[10px] text-white/40 font-mono">Ziada ya TZS 400 zimeongezwa kwenye salio lako.</p>
                </div>
              ) : (
                <form onSubmit={handleSurveySubmit} className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-white/80">Swali 1: Baada ya wiki yako ya kwanza, ni kiwango gani cha SAPC Store unachokipenda zaidi?</p>
                    <div className="grid grid-cols-2 gap-2">
                      {['Kiwango 1 (TZS 6.5k)', 'Kiwango 2 (TZS 13.5k)', 'Kiwango 3 (TZS 25k)', 'Kiwango 4 (TZS 50k)'].map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => setQuizAnswer_1(opt)}
                          className={`py-2 px-3 text-xs rounded-xl border font-mono ${
                            quizAnswer_1 === opt 
                              ? 'bg-orange-500/10 border-orange-500 text-white' 
                              : 'bg-black/40 border-white/10 text-white/40 hover:border-white/20'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-bold text-white/80">Swali 2: Je unaamini AI yetu ya utabiri inakusaidia kuokoa muda wa uchambuzi?</p>
                    <div className="grid grid-cols-2 gap-2">
                      {['Ndiyo, sana!', 'Bahati mbaya hapana', 'Bado nadadisi'].map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => setQuizAnswer_2(opt)}
                          className={`py-2 px-3 text-xs rounded-xl border font-mono ${
                            quizAnswer_2 === opt 
                              ? 'bg-orange-500/10 border-orange-500 text-white' 
                              : 'bg-black/40 border-white/10 text-white/40 hover:border-white/20'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading || completionsToday.length >= maxTasksToday}
                    className="w-full py-2 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 text-black font-extrabold rounded-xl text-xs uppercase hover:scale-[1.01] transition-transform shadow-md"
                  >
                    Tume Utafiti Upokee TZS 400
                  </button>
                </form>
              )}
            </div>

            {/* Type C: Daily Bonus Claim task */}
            <div className="bg-white/[0.02] border border-white/10 p-5 rounded-2xl flex justify-between items-center glass">
              <div className="space-y-1">
                <h4 className="text-sm font-extrabold text-white flex items-center gap-1 font-sans">
                  Bonus ya Siku (Bonus Tasks) <Sparkles className="w-4 h-4 text-orange-400" />
                </h4>
                <p className="text-[10px] text-white/40 font-mono">Bofya kudai TZS 300 upate nyongeza ya haraka katika akaunti.</p>
              </div>
              <button
                disabled={completionsToday.some(c => c.taskType === 'bonus') || completionsToday.length >= maxTasksToday}
                onClick={handleClaimBonusTask}
                className={`py-2 px-4 rounded-xl font-bold uppercase text-xs tracking-wider transition ${
                  completionsToday.some(c => c.taskType === 'bonus')
                    ? 'bg-white/5 text-white/20 border border-white/5 cursor-not-allowed'
                    : 'bg-gradient-to-r from-orange-400 to-orange-500 text-black hover:opacity-90 shadow-lg'
                }`}
              >
                {completionsToday.some(c => c.taskType === 'bonus') ? "Umeshachukua" : "Claim TZS 300"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
