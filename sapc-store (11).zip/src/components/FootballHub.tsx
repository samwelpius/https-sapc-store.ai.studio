import React, { useState, useEffect } from 'react';
import { db, onSnapshot, doc } from '../supabase';
import { UserProfile } from '../types';
import { 
  Trophy, BarChart2, Sparkles, RefreshCw, AlertCircle, ChevronRight, 
  Search, Calendar, Clock, HelpCircle, AlertTriangle, CheckCircle, Info, Zap, Settings as SettingsIcon 
} from 'lucide-react';

interface FootballHubProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
  onAnalyzeFixture: (home: string, away: string, matchId: string) => void;
}

export default function FootballHub({ profile, onNavigate, onAnalyzeFixture }: FootballHubProps) {
  // Filters & State
  const [fixtures, setFixtures] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLeague, setSelectedLeague] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all'); // all, live, upcoming, finished
  const [activeFootballApiKey, setActiveFootballApiKey] = useState(localStorage.getItem('sapc_custom_football_key') || '');

  // Error States
  const [apiError, setApiError] = useState<string | null>(null);
  const [statsError, setStatsError] = useState<string | null>(null);

  // Stats Details State
  const [selectedMatch, setSelectedMatch] = useState<any | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [matchStats, setMatchStats] = useState<any | null>(null);
  const [showStatsModal, setShowStatsModal] = useState(false);

  // Fetch API keys in real-time from Firestore setting or local overrides
  useEffect(() => {
    const unsubGlobal = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (!localStorage.getItem('sapc_custom_football_key')) {
          setActiveFootballApiKey(data.footballApiKey || '');
        }
      }
    });
    return () => unsubGlobal();
  }, []);

  // Fetch match fixtures from API Sports
  const fetchFixtures = async () => {
    setLoading(true);
    setApiError(null);
    try {
      const url = activeFootballApiKey 
        ? `/api/football/fixtures?footballApiKey=${encodeURIComponent(activeFootballApiKey)}`
        : '/api/football/fixtures';
      const resp = await fetch(url);
      const data = await resp.json();
      if (resp.ok) {
        setFixtures(data);
      } else {
        setApiError(data.error || "Imeshindwa kupakia mechi kwa sasa.");
        setFixtures([]);
      }
    } catch (err) {
      setApiError("Kosa la mtandao: Imeshindwa kuungana na seva yetu ya mambo ya soka.");
      console.error("Error fetching fixtures:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFixtures();
  }, [activeFootballApiKey]);

  // Load stats of selected match from server
  const loadMatchStats = async (match: any) => {
    setSelectedMatch(match);
    setStatsLoading(true);
    setMatchStats(null);
    setStatsError(null);
    setShowStatsModal(true);

    try {
      const queryParams = new URLSearchParams({
        id: String(match.id),
        home: match.home || '',
        away: match.away || '',
        score: match.score || '',
        status: match.status || ''
      });
      if (activeFootballApiKey) {
        queryParams.append('footballApiKey', activeFootballApiKey);
      }
      const url = `/api/football/match-stats?${queryParams.toString()}`;
      const resp = await fetch(url);
      const data = await resp.json();
      if (resp.ok) {
        setMatchStats(data);
      } else {
        setStatsError(data.error || "Imeshindwa kupata vigezo au takwimu sahihi za mechi hii kwa sasa.");
      }
    } catch (err) {
      setStatsError("Error ya mfumo wakati wa kusoma takwimu (Network issue).");
      console.error("Error loading statistics:", err);
    } finally {
      setStatsLoading(false);
    }
  };

  // Filter fixtures list
  const filteredFixtures = fixtures.filter((match) => {
    const queryLower = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      match.home.toLowerCase().includes(queryLower) || 
      match.away.toLowerCase().includes(queryLower) || 
      match.league.toLowerCase().includes(queryLower);

    const matchesLeague = selectedLeague === 'all' || 
      (selectedLeague === 'tz' && match.league.toLowerCase().includes('tanzania')) ||
      (selectedLeague === 'epl' && match.league.toLowerCase().includes('premier league')) ||
      (selectedLeague === 'ucl' && match.league.toLowerCase().includes('champions league')) ||
      (selectedLeague === 'laliga' && match.league.toLowerCase().includes('liga')) ||
      (selectedLeague === 'eu' && (match.league.toLowerCase().includes('europe') || match.league.toLowerCase().includes('england')));

    const matchesStatus = selectedStatus === 'all' || 
      (selectedStatus === 'live' && match.status === 'LIVE') ||
      (selectedStatus === 'upcoming' && match.status === 'UPCOMING') ||
      (selectedStatus === 'finished' && match.status === 'FINISHED');

    return matchesSearch && matchesLeague && matchesStatus;
  });

  // Count different statuses
  const countLive = fixtures.filter(m => m.status === 'LIVE').length;
  const countUpcoming = fixtures.filter(m => m.status === 'UPCOMING').length;

  return (
    <div className="space-y-5">
      
      {/* 1. Header Banner */}
      <div className="p-4 bg-gradient-to-r from-orange-500/20 to-transparent border border-white/10 rounded-2xl flex flex-col justify-between items-start gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-orange-500/10 border border-orange-500/20 rounded-xl">
            <Trophy className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h2 className="text-xs font-black text-white uppercase tracking-wider font-mono">
              Football Live & Takwimu Halisi 🏆
            </h2>
            <p className="text-[10px] text-white/50 font-mono mt-0.5">
              Orodha na takwimu halisi za mechi za sasa na zijazo duniani nchini
            </p>
          </div>
        </div>

        <button 
          onClick={fetchFixtures}
          disabled={loading}
          className="py-1 px-3 bg-white/5 hover:bg-white/10 text-white font-mono text-[9px] rounded-lg border border-white/10 uppercase transition-all flex items-center gap-1 cursor-pointer self-end"
        >
          <RefreshCw className={`w-3 h-3 text-orange-400 ${loading ? 'animate-spin' : ''}`} /> Update Sasa EAT
        </button>
      </div>

      {/* 2. Advanced Filter Systems */}
      <div className="bg-slate-950 border border-white/10 rounded-2xl p-3.5 space-y-3 font-mono">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-white/40 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Tafuta mechi, timu au ligi..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-[11px] text-white focus:outline-none focus:border-orange-500 leading-none placeholder-white/30"
          />
        </div>

        {/* Status filters */}
        <div className="grid grid-cols-4 gap-1.5 text-[9px] uppercase font-black text-center">
          <button
            onClick={() => setSelectedStatus('all')}
            className={`py-1.5 rounded-lg border transition ${
              selectedStatus === 'all'
                ? 'bg-orange-500 border-orange-500 text-black'
                : 'bg-white/[0.02] border-white/5 text-white/60 hover:text-white'
            }`}
          >
            Yote ({fixtures.length})
          </button>
          <button
            onClick={() => setSelectedStatus('live')}
            className={`py-1.5 rounded-lg border transition flex items-center justify-center gap-1 ${
              selectedStatus === 'live'
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'bg-white/[0.02] border-white/5 text-emerald-400 hover:text-white'
            }`}
          >
            Live {countLive > 0 && <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />} ({countLive})
          </button>
          <button
            onClick={() => setSelectedStatus('upcoming')}
            className={`py-1.5 rounded-lg border transition ${
              selectedStatus === 'upcoming'
                ? 'bg-orange-500/10 border-orange-500/30 text-orange-400'
                : 'bg-white/[0.02] border-white/5 text-white/60 hover:text-white'
            }`}
          >
            Zijazo ({countUpcoming})
          </button>
          <button
            onClick={() => setSelectedStatus('finished')}
            className={`py-1.5 rounded-lg border transition ${
              selectedStatus === 'finished'
                ? 'bg-white/10 border-white/15 text-white'
                : 'bg-white/[0.02] border-white/5 text-white/60 hover:text-white'
            }`}
          >
            Zilizovunjwa
          </button>
        </div>

        {/* League Quick Filters */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          <button
            onClick={() => setSelectedLeague('all')}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition ${
              selectedLeague === 'all' ? 'bg-white/15 border-white/20 text-white' : 'bg-white/[0.01] border-white/10 text-white/40'
            }`}
          >
            Ligi Zote
          </button>
          <button
            onClick={() => setSelectedLeague('tz')}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition ${
              selectedLeague === 'tz' ? 'bg-orange-500/20 border-orange-500/40 text-orange-400' : 'bg-white/[0.01] border-white/10 text-white/40'
            }`}
          >
            Tanzania Kuu
          </button>
          <button
            onClick={() => setSelectedLeague('epl')}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition ${
              selectedLeague === 'epl' ? 'bg-sky-500/20 border-sky-500/40 text-sky-450' : 'bg-white/[0.01] border-white/10 text-white/40'
            }`}
          >
            English Premier
          </button>
          <button
            onClick={() => setSelectedLeague('ucl')}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition ${
              selectedLeague === 'ucl' ? 'bg-purple-500/20 border-purple-500/40 text-purple-400' : 'bg-white/[0.01] border-white/10 text-white/40'
            }`}
          >
            Ligi ya Champion
          </button>
        </div>
      </div>

      {/* 3. Fixtures List */}
      <div className="space-y-3">
        {apiError && (
          <div className="p-4 bg-red-950/40 border border-red-500/30 rounded-2xl font-mono text-[10px] text-red-200 space-y-1.5 shadow-md">
            <div className="flex items-center gap-1.5 font-bold text-red-400">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
              <span>KOSA LA FOOTBALL API:</span>
            </div>
            <p className="leading-relaxed">{apiError}</p>
            <p className="text-[9px] text-white/40">Thibitisha usajili wako na hakikisha ufunguo haujafikia kikomo cha maombi ya kila siku.</p>
          </div>
        )}

        {loading ? (
          <div className="p-12 text-center bg-slate-950 border border-white/10 rounded-2xl space-y-3">
            <RefreshCw className="w-8 h-8 text-orange-400 mx-auto animate-spin" />
            <p className="text-xs text-white/50 font-mono animate-pulse">Inavuta mechi halisi za leo...</p>
          </div>
        ) : filteredFixtures.length === 0 ? (
          <div className="p-8 text-center bg-slate-950 border border-white/10 rounded-2xl font-mono text-xs text-white/40 italic">
            Hakuna mechi halisi zilizopatikana kwenye kichujio hiki kwa sasa.
          </div>
        ) : (
          filteredFixtures.map((match) => (
            <div 
              key={match.id}
              className="bg-slate-950 border border-white/10 rounded-2xl overflow-hidden hover:border-orange-500/30 transition-all shadow-lg"
            >
              {/* League Header */}
              <div className="px-3.5 py-1.5 bg-white/[0.02] border-b border-white/5 flex justify-between items-center text-[8px] font-bold text-white/40 font-mono uppercase">
                <span>{match.league}</span>
                <span className={`px-1.5 py-0.5 rounded ${
                  match.status === 'LIVE' ? 'bg-red-500/15 text-red-500 border border-red-500/20 animate-pulse' :
                  match.status === 'FINISHED' ? 'bg-white/10 text-white/70' :
                  'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                }`}>
                  {match.status}
                </span>
              </div>

              {/* Match Content */}
              <div className="p-4 flex items-center justify-between font-mono">
                {/* Home */}
                <div className="text-center w-5/12 space-y-1">
                  <div className="text-xs font-bold text-white truncate max-w-[120px] mx-auto">
                    {match.home}
                  </div>
                  <span className="text-[10px] text-white/30 font-black">NYUMBANI</span>
                </div>

                {/* Score / Middle Details */}
                <div className="text-center w-2/12 space-y-1 shrink-0">
                  <div className="text-sm font-black text-white px-2 py-1 bg-black/40 border border-white/5 rounded-lg inline-block">
                    {match.score}
                  </div>
                  <div className="text-[8px] text-orange-400 font-extrabold flex items-center justify-center gap-0.5 leading-none">
                    {match.status === 'LIVE' ? (
                      <>
                        <span className="w-1 h-1 bg-emerald-500 rounded-full animate-ping" />
                        <span>{match.time}</span>
                      </>
                    ) : (
                      <span>{match.time}</span>
                    )}
                  </div>
                </div>

                {/* Away */}
                <div className="text-center w-5/12 space-y-1">
                  <div className="text-xs font-bold text-white truncate max-w-[120px] mx-auto">
                    {match.away}
                  </div>
                  <span className="text-[10px] text-white/30 font-black">UGENINI</span>
                </div>
              </div>

              {/* Match Odds & Actions Footer */}
              <div className="px-3.5 py-2.5 bg-black/40 border-t border-white/5 flex flex-wrap justify-between items-center gap-2">
                
                {/* Dynamic Odds */}
                <div className="flex gap-1.5 text-[8.5px] font-bold font-mono">
                  <div className="px-2 py-0.5 bg-white/5 border border-white/5 rounded text-white/50">
                    H: <span className="text-orange-400 font-black">{match.odds?.home || '2.00'}</span>
                  </div>
                  <div className="px-2 py-0.5 bg-white/5 border border-white/5 rounded text-white/50">
                    D: <span className="text-[#A1A1AA] font-black">{match.odds?.draw || '3.20'}</span>
                  </div>
                  <div className="px-2 py-0.5 bg-white/5 border border-white/5 rounded text-white/50">
                    A: <span className="text-sky-400 font-black">{match.odds?.away || '2.50'}</span>
                  </div>
                </div>

                {/* Main Action Controllers */}
                <div className="flex gap-1.5 w-full justify-end">
                  <button
                    type="button"
                    onClick={() => loadMatchStats(match)}
                    className="w-full py-1.5 bg-[#18181B] hover:bg-white/5 border border-white/10 text-white/80 hover:text-white text-[10px] font-bold rounded-lg uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <BarChart2 className="w-3.5 h-3.5 text-orange-400" /> Takwimu za Mechi
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 4. Standalone Stats and AI prediction Integration Modal */}
      {showStatsModal && selectedMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md bg-slate-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl space-y-4">
            
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 border-b border-white/5 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-orange-400" />
                <h3 className="text-xs font-black text-white uppercase tracking-wider font-mono">
                  Takwimu za Mechi Halisi 📊
                </h3>
              </div>
              <button 
                onClick={() => { setShowStatsModal(false); setMatchStats(null); }}
                className="text-white/40 hover:text-white font-mono text-xs px-2.5 py-1 rounded bg-white/5 border border-white/5 hover:bg-white/10 uppercase transition-all cursor-pointer"
              >
                Funga ✕
              </button>
            </div>

            {/* Modal Contents Scroll Box */}
            <div className="p-5 max-h-[460px] overflow-y-auto space-y-5">
              
              {/* Teams Display banner */}
              <div className="p-3 bg-white/[0.01] border border-white/5 rounded-2xl flex items-center justify-between text-center font-mono">
                <div className="w-5/12 text-[11px] font-bold text-white truncate px-1">
                  {selectedMatch.home}
                </div>
                <div className="shrink-0 px-2.5 py-1 bg-orange-500/15 border border-orange-500/25 text-orange-400 font-extrabold rounded-lg text-[9px] leading-none">
                  {selectedMatch.score}
                </div>
                <div className="w-5/12 text-[11px] font-bold text-white truncate px-1">
                  {selectedMatch.away}
                </div>
              </div>

              {statsLoading ? (
                <div className="py-12 text-center space-y-3 font-mono">
                  <RefreshCw className="w-6 h-6 text-orange-400 mx-auto animate-spin" />
                  <span className="text-[10px] text-white/50 block animate-pulse">Inapakia takwimu halisi toka uwanjani...</span>
                </div>
              ) : statsError ? (
                <div className="py-8 px-4 bg-red-950/20 border border-red-500/20 rounded-2xl text-center font-mono space-y-2">
                  <AlertCircle className="w-6 h-6 text-red-500 mx-auto" />
                  <p className="text-[11px] text-red-400 font-bold uppercase">Hitilafu ya Takwimu</p>
                  <p className="text-[10px] text-white/50 leading-relaxed">{statsError}</p>
                </div>
              ) : matchStats ? (
                <div className="space-y-4 font-mono">
                  
                  {/* Detailed Bar indicators */}
                  <div className="space-y-3 text-xs text-white/80 border-b border-white/5 pb-4">
                    
                    {/* 1. Possession */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] text-white/40 uppercase font-black">
                        <span>{matchStats.possession?.home || '50%'}</span>
                        <span className="text-[#A1A1AA]">Miliki Mpira (Possession)</span>
                        <span>{matchStats.possession?.away || '50%'}</span>
                      </div>
                      <div className="bg-white/5 h-2 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-orange-500 h-full" 
                          style={{ width: `${parseInt(matchStats.possession?.home || '50') || 50}%` }}
                        />
                        <div 
                          className="bg-sky-500 h-full ml-auto" 
                          style={{ width: `${parseInt(matchStats.possession?.away || '50') || 50}%` }}
                        />
                      </div>
                    </div>

                    {/* 2. Shots on goal */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] text-white/40 uppercase font-black">
                        <span>{matchStats.shotsOnGoal?.home || '0'}</span>
                        <span className="text-[#A1A1AA]">Michomo Golini (Shots On Goal)</span>
                        <span>{matchStats.shotsOnGoal?.away || '0'}</span>
                      </div>
                      <div className="bg-white/5 h-1.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-orange-500 h-full" 
                          style={{ 
                            width: `${(matchStats.shotsOnGoal?.home + matchStats.shotsOnGoal?.away) > 0 
                              ? (matchStats.shotsOnGoal?.home / (matchStats.shotsOnGoal?.home + matchStats.shotsOnGoal?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                        <div 
                          className="bg-sky-500 h-full ml-auto" 
                          style={{ 
                            width: `${(matchStats.shotsOnGoal?.home + matchStats.shotsOnGoal?.away) > 0 
                              ? (matchStats.shotsOnGoal?.away / (matchStats.shotsOnGoal?.home + matchStats.shotsOnGoal?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                      </div>
                    </div>

                    {/* 3. Total Shots */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] text-white/40 uppercase font-black">
                        <span>{matchStats.totalShots?.home || '0'}</span>
                        <span className="text-[#A1A1AA]">Jumla ya Mashuti (Total Shots)</span>
                        <span>{matchStats.totalShots?.away || '0'}</span>
                      </div>
                      <div className="bg-white/5 h-1.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-orange-500 h-full" 
                          style={{ 
                            width: `${(matchStats.totalShots?.home + matchStats.totalShots?.away) > 0 
                              ? (matchStats.totalShots?.home / (matchStats.totalShots?.home + matchStats.totalShots?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                        <div 
                          className="bg-sky-500 h-full ml-auto" 
                          style={{ 
                            width: `${(matchStats.totalShots?.home + matchStats.totalShots?.away) > 0 
                              ? (matchStats.totalShots?.away / (matchStats.totalShots?.home + matchStats.totalShots?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                      </div>
                    </div>

                    {/* 4. Corners */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] text-white/40 uppercase font-black">
                        <span>{matchStats.corners?.home || '0'}</span>
                        <span className="text-[#A1A1AA]">Mashuti ya Kona (Corners)</span>
                        <span>{matchStats.corners?.away || '0'}</span>
                      </div>
                      <div className="bg-white/5 h-1.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-orange-500 h-full" 
                          style={{ 
                            width: `${(matchStats.corners?.home + matchStats.corners?.away) > 1 
                              ? (matchStats.corners?.home / (matchStats.corners?.home + matchStats.corners?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                        <div 
                          className="bg-sky-500 h-full ml-auto" 
                          style={{ 
                            width: `${(matchStats.corners?.home + matchStats.corners?.away) > 1 
                              ? (matchStats.corners?.away / (matchStats.corners?.home + matchStats.corners?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                      </div>
                    </div>

                    {/* 5. Fouls */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] text-white/40 uppercase font-black">
                        <span>{matchStats.fouls?.home || '0'}</span>
                        <span className="text-[#A1A1AA]">Kadi / Faulu (Fouls)</span>
                        <span>{matchStats.fouls?.away || '0'}</span>
                      </div>
                      <div className="bg-white/5 h-1.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-orange-500 h-full" 
                          style={{ 
                            width: `${(matchStats.fouls?.home + matchStats.fouls?.away) > 1 
                              ? (matchStats.fouls?.home / (matchStats.fouls?.home + matchStats.fouls?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                        <div 
                          className="bg-sky-500 h-full ml-auto" 
                          style={{ 
                            width: `${(matchStats.fouls?.home + matchStats.fouls?.away) > 1 
                              ? (matchStats.fouls?.away / (matchStats.fouls?.home + matchStats.fouls?.away)) * 100 
                              : 50}%` 
                          }}
                        />
                      </div>
                    </div>

                    {/* 6. Yellow/Red Cards */}
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div className="p-2 bg-black/40 border border-white/5 rounded-xl text-center">
                        <span className="text-[8px] text-[#A1A1AA] block uppercase font-bold mb-0.5">Kadi za Manjano</span>
                        <div className="flex justify-center items-center gap-1.5 text-xs font-bold">
                          <span className="text-orange-400">{matchStats.yellowCards?.home ?? 0}</span>
                          <span className="text-white/20">|</span>
                          <span className="text-sky-400">{matchStats.yellowCards?.away ?? 0}</span>
                        </div>
                      </div>
                      <div className="p-2 bg-black/40 border border-white/5 rounded-xl text-center">
                        <span className="text-[8px] text-[#A1A1AA] block uppercase font-bold mb-0.5">Kadi Nyekundu</span>
                        <div className="flex justify-center items-center gap-1.5 text-xs font-bold">
                          <span className="text-red-500">{matchStats.redCards?.home ?? 0}</span>
                          <span className="text-white/20">|</span>
                          <span className="text-red-400">{matchStats.redCards?.away ?? 0}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              ) : (
                <div className="py-8 text-center text-xs text-white/40 italic font-mono animate-pulse">
                  Kadi za takwimu hazikupatikana hivi sasa. Jaribu tena baadae.
                </div>
              )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
