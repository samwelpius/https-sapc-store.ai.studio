import React, { useState, useEffect } from 'react';
import { db, collection, doc, query, where, getDocs, setDoc, onSnapshot, updateDoc } from '../supabase';
import { UserProfile, SupportTicket, SupportMessage } from '../types';
import { 
  MessageSquare, Plus, Send, RefreshCw, Bot, Sparkles, ShieldCheck, 
  Check, CornerDownRight, AlertCircle, HelpCircle, ArrowLeft, History
} from 'lucide-react';

interface SupportProps {
  profile: UserProfile;
  onBack?: () => void;
}

export default function Support({ profile, onBack }: SupportProps) {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);
  
  // Create ticket form states
  const [showNewForm, setShowNewForm] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Chat reply states
  const [replyText, setReplyText] = useState('');
  const [replyLoading, setReplyLoading] = useState(false);

  // Stream current user tickets
  useEffect(() => {
    setLoading(true);
    const qTickets = query(
      collection(db, 'support_tickets'),
      where('userId', '==', profile.uid)
    );

    const unsubscribe = onSnapshot(qTickets, (snap) => {
      const ticketsList = snap.docs.map(d => d.data() as SupportTicket);
      // Sort by newest
      ticketsList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setTickets(ticketsList);
      
      // Update active ticket instance in real-time if open
      if (activeTicket) {
        const updated = ticketsList.find(t => t.id === activeTicket.id);
        if (updated) {
          setActiveTicket(updated);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile.uid]);

  // Handle support ticket creation
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    if (!subject.trim() || !message.trim()) {
      setFormError("Tafadhali jaza kichwa cha habari na ujumbe wako.");
      return;
    }

    setLoading(true);
    const ticketId = 'ticket-' + Math.random().toString(36).substring(2, 11);
    
    const newTicket: SupportTicket = {
      id: ticketId,
      userId: profile.uid,
      username: profile.username,
      email: profile.email || 'no-email',
      subject: subject.trim(),
      message: message.trim(),
      status: 'pending',
      replies: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'support_tickets', ticketId), newTicket);
      
      // Log an internal activity
      const actId = 'act-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', actId), {
        id: actId,
        userId: profile.uid,
        username: profile.username,
        type: 'support_created',
        message: `Mtumiaji ${profile.username} amefungua tiketi ya msaada: "${subject}"`,
        createdAt: new Date().toISOString()
      });

      setFormSuccess("Tiketi yako ya msaada imefunguliwa na kutumwa! Timu yetu itajibu hivi punde.");
      setSubject('');
      setMessage('');
      setShowNewForm(false);
    } catch (err: any) {
      console.error(err);
      setFormError("Imeshindwa kutuma ticket. Jaribu tena.");
    } finally {
      setLoading(false);
    }
  };

  // Submit User manual reply
  const handleSendReply = async () => {
    if (!activeTicket) return;
    
    let textToSend = replyText.trim();
    if (!textToSend) return;

    setReplyLoading(true);
    try {
      const updatedReplies = [...(activeTicket.replies || [])];
      
      const userReply: SupportMessage = {
        sender: 'user',
        senderName: profile.username,
        message: textToSend,
        createdAt: new Date().toISOString()
      };
      updatedReplies.push(userReply);
      setReplyText('');
      
      await updateDoc(doc(db, 'support_tickets', activeTicket.id), {
        replies: updatedReplies,
        status: 'pending',
        updatedAt: new Date().toISOString()
      });
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Umeshindwa kutuma ujumbe.");
    } finally {
      setReplyLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-white">
      
      {/* HEADER SECTION */}
      <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-4 rounded-2xl glass">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-orange-400" />
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider">HUDUMA KWA WATEJA (SAPC SUPPORT)</h3>
            <p className="text-[10px] text-white/40 font-mono">Uliza swali, ripoti tatizo, au upate msaada wa haraka</p>
          </div>
        </div>
        {onBack && (
          <button 
            onClick={onBack}
            className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-xs font-bold rounded-lg border border-white/5 transition flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Rudi
          </button>
        )}
      </div>

      {activeTicket ? (
        // ACTIVE TICKET CHAT FRAME
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 space-y-4 shadow-xl flex flex-col justify-between">
          <div className="flex justify-between items-center border-b border-white/10 pb-3">
            <button 
              onClick={() => setActiveTicket(null)}
              className="text-white/60 hover:text-white text-xs font-mono flex items-center gap-1 transition"
            >
              <ArrowLeft className="w-4 h-4" /> Tiketi zote ({tickets.length})
            </button>
            <div className="text-right">
              <span className={`px-2 py-0.5 text-[9px] font-bold rounded font-mono uppercase ${
                activeTicket.status === 'pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              }`}>
                {activeTicket.status === 'pending' ? "KUSHUGHULIKIWA" : "IMESHAJIBIWA"}
              </span>
            </div>
          </div>

          <div className="space-y-1 bg-white/[0.02] p-3 rounded-2xl border border-white/5">
            <p className="text-xs font-bold font-mono text-orange-400">MAADA: {activeTicket.subject}</p>
            <p className="text-xs text-white/70 leading-relaxed max-h-20 overflow-y-auto font-sans">{activeTicket.message}</p>
            <span className="block text-[8px] text-white/30 font-mono">{new Date(activeTicket.createdAt).toLocaleString()}</span>
          </div>

          {/* CHAT THREAD MESSAGES */}
          <div className="space-y-3 min-h-[180px] max-h-[300px] overflow-y-auto py-2 pr-1 scrollbar-thin">
            {activeTicket.replies && activeTicket.replies.length > 0 ? (
              activeTicket.replies.map((rep, idx) => {
                const isAdminOrAI = rep.sender === 'admin' || rep.sender === 'ai';
                return (
                  <div 
                    key={idx} 
                    className={`flex flex-col max-w-[85%] ${isAdminOrAI ? 'mr-auto items-start' : 'ml-auto items-end'}`}
                  >
                    <div className="flex items-center gap-1 mb-0.5 text-[8px] text-white/40 font-mono">
                      <span>{rep.senderName}</span>
                      {rep.sender === 'ai' && <Bot className="w-3 h-3 text-cyan-400" />}
                      <span>•</span>
                      <span>{new Date(rep.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    
                    <div className={`p-3 rounded-2xl text-xs font-mono whitespace-pre-wrap leading-relaxed ${
                      isAdminOrAI 
                        ? 'bg-slate-800/80 text-white rounded-tl-none border border-slate-700/50' 
                        : 'bg-orange-500 text-black font-extrabold rounded-tr-none'
                    }`}>
                      {rep.message}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8 space-y-1.5 text-white/35 font-mono">
                <HelpCircle className="w-8 h-8 mx-auto opacity-50 animate-pulse text-orange-400" />
                <p className="text-xs">Hakuna majibu bado kutoka kwa Mhudumu.</p>
                <p className="text-[9px]">Tafadhali subiri admin atakujibu hivi punde.</p>
              </div>
            )}
          </div>

          {/* REPLY ACTION BOX */}
          <div className="space-y-3 border-t border-white/5 pt-3">
            <div className="relative">
              <textarea
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Andika ujumbe wako wa kujibu hapa..."
                className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-2xl text-xs focus:outline-none focus:border-orange-500 text-white h-16 resize-none font-mono"
              />
            </div>

            <div className="flex gap-2 justify-end">
              <button
                type="button"
                disabled={replyLoading || !replyText.trim()}
                onClick={() => handleSendReply()}
                className="px-5 py-2 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 disabled:text-white/20 text-black font-black text-[10px] uppercase rounded-xl transition flex items-center gap-1"
              >
                {replyLoading ? "Kujibu..." : "Tuma Ujumbe"} <Send className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        // DASHBOARD VIEW (LIST OF PAST TICKETS / NEW FORM TRIGGER)
        <div className="space-y-4">
          
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#FFFFFF]/50 font-mono flex items-center gap-1.5">
              <History className="w-4 h-4 text-[#FB923C]" /> Tiketi zako za msaada
            </h4>
            <button
              onClick={() => { setShowNewForm(!showNewForm); setFormError(null); setFormSuccess(null); }}
              className="py-1.5 px-3 bg-gradient-to-r from-orange-400 to-orange-500 text-black font-black text-[11px] rounded-xl flex items-center gap-1 shadow-md shadow-orange-500/5 active:scale-95 transition-transform"
            >
              <Plus className="w-3.5 h-3.5" /> Fungua Msaada
            </button>
          </div>

          {formError && (
            <div className="flex items-start p-3 text-xs rounded bg-red-500/10 border border-red-500/20 text-red-400 gap-2 font-mono">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {formSuccess && (
            <div className="flex items-start p-3 text-xs rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 gap-2 font-mono">
              <Check className="w-4 h-4 shrink-0" />
              <span>{formSuccess}</span>
            </div>
          )}

          {showNewForm && (
            // NEW SUPPORT TICKET DIALOG FORM
            <form onSubmit={handleCreateTicket} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-4 glass animate-fade-in">
              <div className="border-b border-white/5 pb-2">
                <h4 className="text-xs font-bold uppercase text-white/80 font-mono">Omba huduma ya Msaada</h4>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-white/50 uppercase font-mono font-bold">Kichwa cha Msaada (Subject)</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Mfano: Tatizo la Muamala / Kusubiri Boresho la Kiwango / Kuchelewa Kutoa..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-white/50 uppercase font-mono font-bold">Ujumbe kwa kina (Message Details)</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Eleza changamoto yako hapa kwa ukamilifu, ikiwemo Transaction ID, namba ya simu au tarehe kama inahusika..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500 h-24 resize-none"
                  required
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewForm(false)}
                  className="flex-1 py-2 bg-white/5 hover:bg-white/10 text-white/50 font-bold rounded-xl text-xs uppercase"
                >
                  Ghairi
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-2 bg-gradient-to-r from-orange-400 to-orange-500 text-black font-black rounded-xl text-xs uppercase hover:opacity-95 shadow"
                >
                  {loading ? "Inatuma ombi..." : "Wasilisha Tiketi"}
                </button>
              </div>
            </form>
          )}

          {/* LIST VIEW OF THE TICKETS */}
          <div className="space-y-2">
            {loading ? (
              <div className="text-center py-10 font-mono text-white/30 text-xs">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-orange-400" /> Pakia historia ya tiketi...
              </div>
            ) : tickets.length > 0 ? (
              tickets.map((t) => (
                <div 
                  key={t.id}
                  onClick={() => setActiveTicket(t)}
                  className="bg-white/[0.02] border border-white/10 hover:border-orange-500/20 p-4 rounded-2xl flex justify-between items-center cursor-pointer transition-all hover:translate-x-1 glass"
                >
                  <div className="space-y-1.5 max-w-[70%]">
                    <p className="text-xs font-bold text-white tracking-tight leading-tight line-clamp-1 font-mono uppercase">
                      {t.subject}
                    </p>
                    <p className="text-[10px] text-white/50 line-clamp-1 italic font-sans">
                      {t.message}
                    </p>
                    <span className="block text-[8px] text-white/30 font-mono">
                      Yalisasishwa: {new Date(t.updatedAt).toLocaleDateString()} saa {new Date(t.updatedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </span>
                  </div>

                  <div className="text-right flex flex-col items-end gap-1.5">
                    <span className={`px-2 py-0.5 text-[8px] font-bold rounded uppercase font-mono ${
                      t.status === 'pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {t.status === 'pending' ? 'Bado' : 'Imejibiwa'}
                    </span>
                    {t.replies && t.replies.length > 0 && (
                      <span className="text-[8px] text-orange-400 font-mono font-bold flex items-center gap-0.5 uppercase">
                        <CornerDownRight className="w-2.5 h-2.5 mt-0.5" /> {t.replies.length} majibu
                      </span>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white/[0.01] border dashed border-white/10 p-10 rounded-2xl text-center space-y-2 text-white/35 font-mono">
                <MessageSquare className="w-8 h-8 text-orange-400 opacity-60 mx-auto" />
                <p className="text-xs">Hujawahi kufungua tiketi yoyote ya msaada bado.</p>
                <p className="text-[9px]">SAPC Customer Support msaada uko hapa kukusaidia haraka wakati wowote masaa yote!</p>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
