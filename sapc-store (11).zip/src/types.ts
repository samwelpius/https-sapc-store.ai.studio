export interface UserProfile {
  uid: string;
  email: string;
  username: string;
  balance: number;
  totalEarnings: number;
  totalReferrals: number;
  level: number; // 0, 1, 2, 3, 4
  referralCode: string;
  referredBy?: string;
  vipUntil?: string; // ISO date-time
  createdAt: string;
  role: 'user' | 'admin';
  deviceInfo?: string;
  phoneNumber?: string;
  status?: 'active' | 'suspended';
  points?: number; // accumulated video points
  totalPoints?: number; // total points earned
}

export interface InvestmentLevel {
  id: number;
  title: string;
  cost: number;
  tasksCount: number;
  dailyIncome: number;
  referralBonus: number;
  description: string;
}

export const INVESTMENT_LEVELS: Record<number, InvestmentLevel> = {
  0: {
    id: 0,
    title: "Kiwango cha Bure",
    cost: 0,
    tasksCount: 2,
    dailyIncome: 500,
    referralBonus: 0,
    description: "Kiwango cha majaribio bila malipo"
  },
  1: {
    id: 1,
    title: "Kiwango 1",
    cost: 6500,
    tasksCount: 5,
    dailyIncome: 2500,
    referralBonus: 2000,
    description: "Mtaji: TZS 6,500 | Mapato: TZS 2,500/Siku"
  },
  2: {
    id: 2,
    title: "Kiwango 2",
    cost: 13500,
    tasksCount: 10,
    dailyIncome: 5000,
    referralBonus: 5000,
    description: "Mtaji: TZS 13,500 | Mapato: TZS 5,000/Siku"
  },
  3: {
    id: 3,
    title: "Kiwango 3",
    cost: 25000,
    tasksCount: 15,
    dailyIncome: 7500,
    referralBonus: 10000,
    description: "Mtaji: TZS 25,000 | Mapato: TZS 7,500/Siku"
  },
  4: {
    id: 4,
    title: "Kiwango 4",
    cost: 50000,
    tasksCount: 25,
    dailyIncome: 12500,
    referralBonus: 10000,
    description: "Mtaji: TZS 50,000 | Mapato: TZS 12,500/Siku"
  }
};

export interface UpgradeRequest {
  id: string;
  userId: string;
  username: string;
  fromLevel: number;
  toLevel: number;
  amount: number;
  paymentMethod: string;
  transactionId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface DepositRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  phone: string;
  paymentMethod: string;
  transactionId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  phone: string;
  paymentMethod: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface VideoTask {
  id: string;
  title: string;
  videoUrl: string;
  rewardAmount: number;
  duration: number; // in seconds
  active: boolean;
  createdAt: string;
}

export interface TaskCompletion {
  id: string;
  userId: string;
  taskType: 'video' | 'football' | 'survey' | 'bonus';
  taskId: string;
  reward: number;
  date: string; // YYYY-MM-DD
  completedAt: string;
}

export interface AIPrediction {
  id: string;
  userId: string;
  homeTeam: string;
  awayTeam: string;
  isVip: boolean;
  createdAt: string;
  response: {
    homeWinProb: number;
    awayWinProb: number;
    drawProb: number;
    overUnder: string;
    btts: string;
    correctScore: string;
    analysis: string;
  };
}

export interface InAppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'deposit' | 'withdrawal' | 'task' | 'referral' | 'general';
  read: boolean;
  createdAt: string;
}

export interface SystemSettings {
  id: string;
  footballApiKey?: string;
  liveScoresApi?: string;
  fixturesApi?: string;
  oddsApi?: string;
  openaiApiKey?: string;
  geminiApiKey?: string;
  deepseekApiKey?: string;
  claudeApiKey?: string;
  mPesaNumber?: string;
  airtelNumber?: string;
  tigoNumber?: string;
  haloNumber?: string;
  dailyWithdrawLimit?: number;
}

export interface SupportMessage {
  sender: 'user' | 'admin' | 'ai';
  senderName: string;
  message: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  username: string;
  email: string;
  subject: string;
  message: string;
  status: 'pending' | 'answered' | 'closed';
  replies: SupportMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface SystemAdvertisement {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
  link?: string;
  active: boolean;
  createdAt: string;
}

